"""macOS application discovery, bounded data discovery and user-selected locations."""
from __future__ import annotations

import base64
import json
import os
import stat
import subprocess
import tempfile
import threading
from enum import Enum
from pathlib import Path

WECHAT_BUNDLE_ID = "com.tencent.xinWeChat"
DATABASE_LAYOUTS = (
    Path("db_storage/emoticon/emoticon.db"),
)


class LocationCode(str, Enum):
    APP_MISSING = "app_missing"
    PERMISSION = "permission"
    DATA_MISSING = "data_missing"
    DATA_INVALID = "data_invalid"
    SETTINGS_INVALID = "settings_invalid"


class LocationError(RuntimeError):
    def __init__(self, code, title, detail, path=None):
        self.code, self.title, self.path = code, title, str(path or "")
        super().__init__(detail + (f"\n目录：{path}" if path else ""))

    def status(self):
        return {"tone": "error", "code": self.code.value,
                "title": self.title, "detail": str(self), "path": self.path}


def installed_wechat():
    from AppKit import NSWorkspace

    workspace = NSWorkspace.sharedWorkspace()
    running = [app for app in workspace.runningApplications()
               if str(app.bundleIdentifier()) == WECHAT_BUNDLE_ID]
    apps = [(Path(str(app.bundleURL().path())), int(app.processIdentifier()))
            for app in running if app.bundleURL()]
    registered = workspace.URLForApplicationWithBundleIdentifier_(WECHAT_BUNDLE_ID)
    if registered:
        path = Path(str(registered.path()))
        if path not in [item[0] for item in apps]:
            apps.append((path, 0))
    return apps


def application_path():
    for path, _pid in installed_wechat():
        if path.is_dir():
            return path
    raise LocationError(LocationCode.APP_MISSING, "没有找到微信应用",
                        "请先安装并打开一次 Mac 微信，再点重新检测。")


def system_directory(kind):
    from Foundation import NSFileManager, NSUserDomainMask

    urls = NSFileManager.defaultManager().URLsForDirectory_inDomains_(kind, NSUserDomainMask)
    if not urls:
        raise RuntimeError("macOS 未返回用户目录。")
    return Path(str(urls[0].path()))


def application_data_directory(name):
    from Foundation import NSApplicationSupportDirectory

    return system_directory(NSApplicationSupportDirectory) / name


def browser_cache_directory():
    from Foundation import NSCachesDirectory

    return system_directory(NSCachesDirectory) / "ms-playwright"


def running_data_roots(apps):
    """Only inspect filenames held by WeChat; never read database contents."""
    roots = []
    for _app, pid in apps:
        if not pid:
            continue
        try:
            result = subprocess.run(
                ["/usr/sbin/lsof", "-a", "-p", str(pid), "-Fn"],
                capture_output=True, text=True, timeout=8, check=False,
            )
        except (OSError, subprocess.TimeoutExpired):
            continue
        for line in result.stdout.splitlines():
            if not line.startswith("n/"):
                continue
            path = Path(line[1:])
            # 4.x database/cache layout identifies an account without its name.
            for marker in ("db_storage", "FileStorage"):
                if marker in path.parts:
                    index = path.parts.index(marker)
                    if index > 1:
                        roots.append(Path(*path.parts[:index]).parent)
    return list(dict.fromkeys(roots))


def settings_path():
    import config

    return Path(config.DATA_DIR) / "wechat-location.json"


_active_urls = []  # Keep security-scoped URLs alive while the app is using them.


def saved_location():
    from Foundation import (
        NSURL,
        NSData,
        NSURLBookmarkResolutionWithoutUI,
        NSURLBookmarkResolutionWithSecurityScope,
    )

    try:
        data = json.loads(settings_path().read_text())
    except FileNotFoundError:
        return None
    except (OSError, ValueError) as exc:
        raise LocationError(LocationCode.SETTINGS_INVALID, "无法读取上次选择的目录",
                            "请重新选择微信数据目录。") from exc
    if (not isinstance(data, dict) or set(data) != {"version", "path", "bookmark", "scoped"}
            or data["version"] != 1 or not isinstance(data["path"], str)
            or not isinstance(data["bookmark"], str) or type(data["scoped"]) is not bool):
        raise LocationError(LocationCode.SETTINGS_INVALID, "目录记录无效", "请重新选择微信数据目录。")
    if data["bookmark"]:
        try:
            raw = base64.b64decode(data["bookmark"], validate=True)
            bookmark = NSData.dataWithBytes_length_(raw, len(raw))
            options = NSURLBookmarkResolutionWithoutUI
            if data["scoped"]:
                options |= NSURLBookmarkResolutionWithSecurityScope
            url, _stale, _error = NSURL.URLByResolvingBookmarkData_options_relativeToURL_bookmarkDataIsStale_error_(
                bookmark, options, None, None, None)
            if url:
                if url.startAccessingSecurityScopedResource():
                    _active_urls.append(url)
                return Path(str(url.path()))
        except (ValueError, TypeError):
            pass
    return Path(data["path"])


def save_location(selected, url=None):
    from Foundation import NSURL, NSURLBookmarkCreationWithSecurityScope

    selected = Path(selected).expanduser().resolve()
    # Validate first; an invalid selection must not replace a working preference.
    accounts_from_selection(selected)
    url = url or NSURL.fileURLWithPath_(str(selected))
    bookmark, _error = url.bookmarkDataWithOptions_includingResourceValuesForKeys_relativeToURL_error_(
        NSURLBookmarkCreationWithSecurityScope, None, None, None)
    scoped = bool(bookmark)
    if not bookmark:
        bookmark, _error = url.bookmarkDataWithOptions_includingResourceValuesForKeys_relativeToURL_error_(
            0, None, None, None)
    data = {"version": 1, "path": str(selected),
            "bookmark": base64.b64encode(bytes(bookmark)).decode() if bookmark else "",
            "scoped": scoped}
    target = settings_path()
    target.parent.mkdir(parents=True, exist_ok=True)
    target.parent.chmod(0o700)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", dir=target.parent,
                                         delete=False) as stream:
            temporary = Path(stream.name)
            json.dump(data, stream, ensure_ascii=False)
        temporary.replace(target)
    finally:
        if temporary:
            temporary.unlink(missing_ok=True)
    return selected


def choose_location(initial=""):
    """Show the real NSOpenPanel, including a currently denied initial directory."""
    from AppKit import NSModalResponseOK, NSOpenPanel
    from Foundation import NSURL, NSThread
    from PyObjCTools import AppHelper

    done, result = threading.Event(), {}

    def show():
        try:
            panel = NSOpenPanel.openPanel()
            panel.setTitle_("选择微信数据目录")
            panel.setMessage_("选择微信数据文件夹并点“允许读取”。根目录或账号目录都可以。")
            panel.setPrompt_("允许读取")
            panel.setCanChooseDirectories_(True)
            panel.setCanChooseFiles_(False)
            panel.setAllowsMultipleSelection_(False)
            panel.setCanCreateDirectories_(False)
            panel.setShowsHiddenFiles_(True)
            if initial:
                panel.setDirectoryURL_(NSURL.fileURLWithPath_(initial))
            if panel.runModal() == NSModalResponseOK:
                result["url"] = panel.URL()
        except Exception as exc:
            result["error"] = exc
        finally:
            done.set()

    if NSThread.isMainThread():
        show()
    else:
        AppHelper.callAfter(show)
        done.wait()
    if "error" in result:
        raise result["error"]
    if "url" in result:
        url = result["url"]
        if url.startAccessingSecurityScopedResource():
            _active_urls.append(url)
        return save_location(str(url.path()), url)
    return None


def data_roots(preferred=None):
    from Foundation import NSDocumentDirectory, NSLibraryDirectory

    library = system_directory(NSLibraryDirectory)
    sandbox = library / "Containers" / WECHAT_BUNDLE_ID / "Data"
    roots = [saved_location()]
    if preferred:
        roots.append(Path(preferred).expanduser())
    roots.extend(running_data_roots(installed_wechat()))
    roots.extend((system_directory(NSDocumentDirectory) / "xwechat_files",
                  sandbox / "Documents" / "xwechat_files",
                  sandbox / "Library" / "Application Support" / WECHAT_BUNDLE_ID / "xwechat_files"))
    return list(dict.fromkeys(root for root in roots if root is not None))


def _stat(path):
    try:
        return path.stat()
    except FileNotFoundError:
        return None
    except PermissionError as exc:
        raise LocationError(LocationCode.PERMISSION, "需要允许读取微信数据",
                            "点“选择并允许读取”，在系统窗口中选择微信数据目录并点打开。", path) from exc


def is_account(path):
    return any((info := _stat(path / layout)) and stat.S_ISREG(info.st_mode)
               for layout in DATABASE_LAYOUTS)


def readable_account(path):
    try:
        # Opening without reading checks the permission the extraction helper needs.
        with (path / DATABASE_LAYOUTS[0]).open("rb"):
            pass
    except PermissionError as exc:
        raise LocationError(LocationCode.PERMISSION, "需要允许读取微信表情数据库",
                            "点“选择并允许读取”，在系统窗口中选中此账号目录并点允许读取。", path) from exc
    return path


def accounts_from_selection(selected):
    """Accept account, root, nearby parent, or a directory inside an account."""
    selected = Path(selected).expanduser().resolve()
    info = _stat(selected)
    if not info:
        raise LocationError(LocationCode.DATA_MISSING, "微信数据目录不存在",
                            "请重新选择这台 Mac 实际使用的微信数据目录。", selected)
    if not stat.S_ISDIR(info.st_mode):
        raise LocationError(LocationCode.DATA_INVALID, "请选择文件夹", "需要选择微信数据文件夹。", selected)
    # Walk up only to locate a database-bearing account, never scan siblings there.
    for ancestor in (selected, *list(selected.parents)[:5]):
        if is_account(ancestor):
            return [readable_account(ancestor)]
    pending, found, denied, visited = [(selected, 0)], [], [], 0
    while pending:
        path, depth = pending.pop(0)
        if is_account(path):
            try:
                found.append(readable_account(path))
            except LocationError as exc:
                denied.append(exc)
            continue
        if depth == 3:
            continue
        try:
            with os.scandir(path) as entries:
                children = [Path(entry.path) for entry in entries
                            if not entry.name.startswith(".") and entry.is_dir(follow_symlinks=False)]
        except PermissionError as exc:
            raise LocationError(LocationCode.PERMISSION, "需要允许读取微信数据",
                                "点“选择并允许读取”，重新选择此目录并点打开。", path) from exc
        visited += len(children)
        if visited > 1500:
            raise LocationError(LocationCode.DATA_INVALID, "选择的范围太大",
                                "请选择更具体的微信数据文件夹，例如 xwechat_files。", selected)
        pending.extend((child, depth + 1) for child in children)
    if not found:
        if denied:
            raise denied[0]
        raise LocationError(LocationCode.DATA_INVALID, "此目录没有可识别的表情数据库",
                            "请在本机微信 4.x 登录并同步收藏表情，或选择其他数据目录。", selected)
    return sorted(set(found))


def discover_accounts(preferred=None):
    found, errors = {}, []
    for root in data_roots(preferred):
        try:
            for account in accounts_from_selection(root):
                found.setdefault(str(account), account)
        except LocationError as exc:
            errors.append(exc)
    if found:
        return list(found.values())
    for code in (LocationCode.PERMISSION, LocationCode.DATA_INVALID, LocationCode.DATA_MISSING):
        for error in errors:
            if error.code == code:
                raise error
    raise LocationError(LocationCode.DATA_MISSING, "没有找到微信数据目录",
                        "请打开本机微信并同步收藏，或点“选择并允许读取”手动定位。")

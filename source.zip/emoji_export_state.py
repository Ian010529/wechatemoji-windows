"""Versioned hashes distinguish animation-safe exports from legacy files."""
import hashlib
import json
import tempfile
from pathlib import Path

INDEX_NAME = ".animation-safe-exports.json"


def write_export(folder, stem, extension, data):
    from emoji_images import validate_image

    validate_image(data)
    root = Path(folder)
    target = root / f"{stem}.{extension}"
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(dir=root, delete=False) as stream:
            temporary = Path(stream.name)
            stream.write(data)
        temporary.replace(target)
    finally:
        if temporary:
            temporary.unlink(missing_ok=True)
    # A repaired APNG/WebP may now be a GIF; remove only that sticker's stale representation.
    for old in root.glob(f"{stem}.*"):
        if old != target and old.suffix.lower() in {".gif", ".png", ".jpg", ".jpeg", ".webp"}:
            old.unlink()
    return str(target)


def verified_exports(folder):
    root = Path(folder)
    try:
        data = json.loads((root / INDEX_NAME).read_text())
        if set(data) != {"version", "files"} or data["version"] != 1 or not isinstance(data["files"], dict):
            return {}
    except (OSError, ValueError, TypeError):
        return {}
    result = {}
    for name, digest in data["files"].items():
        if not isinstance(name, str) or Path(name).name != name:
            continue
        path = root / name
        try:
            if not path.is_symlink() and hashlib.sha256(path.read_bytes()).hexdigest() == digest:
                result[path.stem] = str(path)
        except OSError:
            continue
    return result


def record_exports(folder, files):
    root = Path(folder)
    data = {Path(path).name: hashlib.sha256(Path(path).read_bytes()).hexdigest() for path in files}
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", dir=root, delete=False) as stream:
            temporary = Path(stream.name)
            json.dump({"version": 1, "files": data}, stream)
        temporary.replace(root / INDEX_NAME)
    finally:
        if temporary:
            temporary.unlink(missing_ok=True)


def shelve_unverified(folder, source_ids, verified_files):
    root, verified = Path(folder), {Path(file) for file in verified_files}
    for path in root.iterdir():
        if (path.is_file() and path not in verified and path.stem in source_ids
                and path.suffix.lower() in {".gif", ".png", ".jpg", ".jpeg", ".webp"}):
            saved = root / ".legacy-unverified"
            saved.mkdir(exist_ok=True)
            path.replace(saved / path.name)

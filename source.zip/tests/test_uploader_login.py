"""AI-drafted login regressions; no network or real browser sessions."""
import unittest
from types import SimpleNamespace
from unittest.mock import Mock, patch

from feishu_uploader import FeishuUploader


class LoginTests(unittest.TestCase):
    def test_qr_login_adopts_new_authenticated_page(self):
        uploader = FeishuUploader()
        initial = SimpleNamespace(url="https://accounts.feishu.cn/accounts/page/login")
        messenger = SimpleNamespace(url="https://tenant.feishu.cn/next/messenger/")
        uploader._page = initial
        uploader._context = SimpleNamespace(pages=[initial, messenger])
        self.assertTrue(uploader._is_logged_in())
        self.assertIs(uploader._page, messenger)

    def test_query_redirect_does_not_misclassify_authenticated_route(self):
        uploader = FeishuUploader()
        uploader._page = SimpleNamespace(url="https://tenant.feishu.cn/next/messenger/?from=/sso/login")
        self.assertTrue(uploader._is_logged_in())

    def test_login_and_unrelated_domains_are_rejected(self):
        uploader = FeishuUploader()
        for url in ["https://accounts.feishu.cn/login?redirect_uri=/messenger/",
                    "https://example.test/messenger/",
                    "https://evilfeishu.cn/messenger/",
                    "https://tenant.feishu.cn/passport/sso/messenger/"]:
            with self.subTest(url=url):
                uploader._page = SimpleNamespace(url=url)
                self.assertFalse(uploader._is_logged_in())

    def test_login_wait_pumps_browser_navigation_events(self):
        uploader = FeishuUploader()
        page = Mock()
        page.url = "https://accounts.feishu.cn/accounts/page/login"
        ticks = []
        def browser_wait(milliseconds):
            ticks.append(milliseconds)
            if len(ticks) == 2:
                page.url = "https://tenant.feishu.cn/next/messenger/"
        page.wait_for_timeout.side_effect = browser_wait
        uploader._page = page
        uploader._context = SimpleNamespace(pages=[page])
        with patch("feishu_uploader.time.sleep", side_effect=AssertionError("Must pump Playwright events")):
            self.assertTrue(uploader.login())
        self.assertEqual(ticks, [1500, 1500])


if __name__ == "__main__":
    unittest.main()

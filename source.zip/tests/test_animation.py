"""AI-drafted regressions using synthetic images; no network or real credentials."""
import tempfile
import unittest
from io import BytesIO
from pathlib import Path
from unittest.mock import patch

from PIL import Image, ImageDraw

import wechat_extractor as extractor
from emoji_export_state import record_exports, verified_exports, write_export


def animation(fmt="GIF", size=(80, 80), default=False):
    frames = []
    for index in range(3):
        frame = Image.new("RGBA", size, (0, 0, 0, 0))
        ImageDraw.Draw(frame).rectangle((index * 10, 5, index * 10 + 15, 20), fill=(255, 0, 0, 255))
        frames.append(frame)
    stream = BytesIO()
    options = {"lossless": True} if fmt == "WEBP" else {}
    if default:
        frames.insert(0, Image.new("RGBA", size, "blue"))
        options["default_image"] = True
    frames[0].save(stream, format=fmt, save_all=True, append_images=frames[1:],
                   duration=[60, 120, 180], loop=2, disposal=2 if fmt == "GIF" else 0,
                   **options)
    return stream.getvalue()


def stats(data):
    with Image.open(BytesIO(data)) as image:
        durations = []
        for index in range(image.n_frames):
            image.seek(index)
            image.load()
            durations.append(image.info.get("duration", 0))
        return image.n_frames, durations, image.info.get("loop"), image.size


class AnimationTests(unittest.TestCase):
    def test_small_gif_is_byte_identical_not_first_frame(self):
        raw = animation()
        result = extractor.process_image(raw)
        self.assertEqual(result, raw)
        self.assertEqual(stats(result)[:3], (3, [60, 120, 180], 2))

    def test_large_gif_keeps_frames_timing_loop_and_transparency(self):
        result = extractor.process_image(animation(size=(800, 600)))
        count, durations, loop, size = stats(result)
        self.assertEqual((count, durations, loop, size), (3, [60, 120, 180], 2, (400, 300)))
        with Image.open(BytesIO(result)) as image:
            for index in range(3):
                image.seek(index)
                self.assertEqual(image.convert("RGBA").getpixel((200, 200))[3], 0)

    def test_other_animated_formats_become_multiframe_gif(self):
        for fmt, default in (("WEBP", False), ("PNG", False), ("PNG", True)):
            with self.subTest(fmt=fmt, default=default):
                result = extractor.process_image(animation(fmt, default=default))
                self.assertEqual(extractor.detect_image_format(result), "gif")
                self.assertEqual(stats(result)[:3], (3, [60, 120, 180], 2))

    def test_encoder_failure_keeps_original_animation(self):
        raw = animation(size=(500, 500))
        with patch.object(Image.Image, "save", side_effect=OSError("encoder failed")):
            result = extractor.process_image(raw)
        self.assertEqual(result, raw)
        self.assertEqual(stats(result)[0], 3)

    def test_corrupt_image_header_is_not_accepted_as_download(self):
        invalid = b"GIF89a" + bytes(200)
        response = BytesIO(invalid)
        with patch("wechat_extractor.urllib.request.urlopen", return_value=response):
            self.assertIsNone(extractor.download_emoji("https://example.test/image"))

    def test_legacy_and_modified_exports_are_not_trusted(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "abc.gif"
            path.write_bytes(animation())
            self.assertEqual(verified_exports(directory), {})
            record_exports(directory, [str(path)])
            self.assertEqual(verified_exports(directory), {"abc": str(path)})
            path.write_bytes(b"changed")
            self.assertEqual(verified_exports(directory), {})

    def test_replaced_format_removes_only_the_old_sticker_representation(self):
        with tempfile.TemporaryDirectory() as directory:
            old = Path(directory) / "abc.png"
            unrelated = Path(directory) / "other.png"
            old.write_bytes(b"old flattened file")
            unrelated.write_bytes(b"unrelated")
            result = write_export(directory, "abc", "gif", animation())
            self.assertEqual(stats(Path(result).read_bytes())[0], 3)
            self.assertFalse(old.exists())
            self.assertEqual(unrelated.read_bytes(), b"unrelated")

    def test_failed_atomic_replacement_preserves_existing_image(self):
        with tempfile.TemporaryDirectory() as directory:
            old = Path(directory) / "abc.gif"
            old.write_bytes(animation())
            before = old.read_bytes()
            with patch.object(Path, "replace", side_effect=OSError("disk error")):
                with self.assertRaises(OSError):
                    write_export(directory, "abc", "gif", b"replacement")
            self.assertEqual(old.read_bytes(), before)

    def test_startup_blocks_legacy_export_until_repaired(self):
        from macos_desktop.simple_desktop import SimpleApi

        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "abc.gif"
            path.write_bytes(animation())
            api = object.__new__(SimpleApi)
            with patch("config.EMOJI_OUTPUT_DIR", directory):
                result = api.simpleInit()
                self.assertEqual((result["count"], result["repairCount"]), (0, 1))
                self.assertEqual(api.emoji_files, [])
                record_exports(directory, [str(path)])
                result = api.simpleInit()
                self.assertEqual((result["count"], result["repairCount"]), (1, 0))
    def test_legacy_static_export_is_redownloaded_then_resumed(self):
        raw = animation()
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            output = root / "output"
            output.mkdir()
            old = output / "abc.gif"
            with Image.open(BytesIO(raw)) as image:
                image.save(old, format="GIF")
            db = root / "db"
            db.touch()
            with patch.object(extractor, "get_wechat_info", return_value=[{
                "wxid": "synthetic", "wx_dir": str(root), "running": True}]), \
                    patch.object(extractor, "find_emoticon_db", return_value=str(db)), \
                    patch.object(extractor, "download_emoji", return_value=raw) as download, \
                    patch.object(extractor, "scan_custom_emotion_cache", return_value=[]), \
                    patch("macos_wechat.query_emoji_entries", return_value=[{
                        "md5": "abc", "url": "https://example.test/synthetic"}]), \
                    patch("config.TMP_DIR", str(root / "temporary")), \
                    patch("wechat_extractor.sys.platform", "darwin"):
                self.assertEqual(extractor.extract_emojis(output_dir=str(output)), [str(old)])
                self.assertEqual(stats(old.read_bytes())[0], 3)
                self.assertEqual(extractor.extract_emojis(output_dir=str(output)), [str(old)])
                self.assertEqual(download.call_count, 1)
                old.write_bytes(animation(size=(81, 81)))
                self.assertEqual(extractor.extract_emojis(output_dir=str(output)), [str(old)])
                self.assertEqual(download.call_count, 2)
                self.assertEqual(old.read_bytes(), raw)

    def test_correct_legacy_bytes_are_reused_without_preserving_flattened_animation(self):
        from emoji_images import reusable_legacy_image

        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "image.gif"
            raw = animation()
            path.write_bytes(raw)
            self.assertEqual(reusable_legacy_image(path, raw, 400), raw)
            with Image.open(BytesIO(raw)) as image:
                image.save(path)
            self.assertIsNone(reusable_legacy_image(path, raw, 400))

    def test_failed_redownload_does_not_certify_old_static_file(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            output = root / "output"
            output.mkdir()
            old = output / "abc.gif"
            Image.new("RGB", (10, 10), "red").save(old)
            with patch.object(extractor, "get_wechat_info", return_value=[{
                "wxid": "synthetic", "wx_dir": str(root), "running": True}]), \
                    patch.object(extractor, "find_emoticon_db", return_value="synthetic.db"), \
                    patch.object(extractor, "download_emoji", return_value=None), \
                    patch.object(extractor, "scan_custom_emotion_cache", return_value=[]), \
                    patch("macos_wechat.query_emoji_entries", return_value=[{"md5": "abc", "url": "synthetic"}]), \
                    patch("config.TMP_DIR", str(root / "temporary")), \
                    patch("wechat_extractor.sys.platform", "darwin"):
                self.assertEqual(extractor.extract_emojis(output_dir=str(output)), [])
                self.assertEqual(verified_exports(output), {})


if __name__ == "__main__":
    unittest.main()

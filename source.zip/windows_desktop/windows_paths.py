"""Windows path adapter: OS Known Folders plus a validated per-user selection."""
import ctypes
import json
import os
import tempfile
import uuid
from pathlib import Path

import config

DATABASES = ('db_storage/emoticon/emoticon.db', 'FileStorage/Emoticon/emoticon.db', 'Emoticon/emoticon.db')


def documents_directory():
    """Ask Windows for Documents, including OneDrive and redirected folders."""
    from ctypes import wintypes

    folder_id = (ctypes.c_ubyte * 16).from_buffer_copy(
        uuid.UUID('FDD39AD0-238F-46AF-ADB4-6C85480369C7').bytes_le)
    result = ctypes.c_wchar_p()
    shell = ctypes.WinDLL('shell32', use_last_error=True)
    shell.SHGetKnownFolderPath.argtypes = [ctypes.c_void_p, wintypes.DWORD, wintypes.HANDLE,
                                         ctypes.POINTER(ctypes.c_wchar_p)]
    shell.SHGetKnownFolderPath.restype = ctypes.c_long
    status = shell.SHGetKnownFolderPath(ctypes.byref(folder_id), 0, None, ctypes.byref(result))
    if status != 0:
        raise OSError(f'Windows Documents 查询失败（{status}）')
    try:
        return Path(result.value)
    finally:
        ole = ctypes.WinDLL('ole32')
        ole.CoTaskMemFree.argtypes = [ctypes.c_void_p]
        ole.CoTaskMemFree(ctypes.cast(result, ctypes.c_void_p))


def accounts(root):
    try:
        children = list(Path(root).iterdir())
    except OSError:
        return []
    return sorted(p for p in children if p.is_dir() and p.name.startswith('wxid_')
                  and any((p / name).is_file() for name in DATABASES))


def selected_root():
    try:
        value = json.loads((Path(config.DATA_DIR) / 'windows-location.json').read_text())
        if set(value) != {'data_root'} or not isinstance(value['data_root'], str):
            return None
        root = Path(value['data_root'])
        return root if accounts(root) else None
    except (OSError, ValueError, TypeError):
        return None


def data_roots():
    roots = []
    for value in (config.WECHAT_FILES_ROOT, selected_root()):
        if value and Path(value) not in roots:
            roots.append(Path(value))
    documents = documents_directory()
    for value in (documents / 'xwechat_files', documents / 'WeChat Files'):
        if value not in roots:
            roots.append(value)
    return [str(root) for root in roots]


def resolve_selection(selected):
    selected = Path(selected).resolve()
    if not selected.is_dir():
        raise ValueError('选择的目录不存在。请重新选择微信数据目录。')
    candidates = [selected, selected.parent, selected.parent.parent]
    candidates += [selected / name for name in ('xwechat_files', 'WeChat Files')]
    for root in candidates:
        if accounts(root):
            return root
    raise ValueError('这个目录里没有找到微信账号。请选择 xwechat_files、WeChat Files 或 wxid_ 开头的账号目录。')


def remember(root):
    destination = Path(config.DATA_DIR) / 'windows-location.json'
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(mode='w', encoding='utf-8', dir=destination.parent,
                                         delete=False) as stream:
            temporary = Path(stream.name)
            json.dump({'data_root': str(root)}, stream)
        os.replace(temporary, destination)
    finally:
        if temporary:
            temporary.unlink(missing_ok=True)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$project = Split-Path $PSScriptRoot -Parent
Set-Location $project
$python = (Get-Command python.exe).Source
function Run-Python([string[]]$Parameters) {
    & $python @Parameters
    if ($LASTEXITCODE -ne 0) { throw "Python step failed: $($Parameters -join ' ')" }
}
Run-Python -Parameters @('-m','pip','install','-r','windows_desktop/requirements.txt')
$env:PYTHONPATH = "$project;$project\macos_desktop;$project\windows_desktop"
Run-Python -Parameters @('-m','unittest','discover','-s','windows_desktop','-p','test_*.py')
Run-Python -Parameters @('-m','unittest','discover','-s','macos_desktop','-p','test_*.py')
Run-Python -Parameters @('-m','unittest','discover','-s','tests','-p','test_animation.py')
Run-Python -Parameters @('-m','unittest','discover','-s','tests','-p','test_uploader_login.py')
New-Item -ItemType Directory -Force evidence | Out-Null
Run-Python -Parameters @('windows_desktop/prepare_licenses.py')
& $python -m pip freeze | Set-Content evidence\dependencies.txt -Encoding utf8
$env:PLAYWRIGHT_BROWSERS_PATH = Join-Path $project 'vendor\ms-playwright'
Run-Python -Parameters @('-m','playwright','install','chromium','--no-shell')
New-Item -ItemType Directory -Force vendor\webview2,release,evidence | Out-Null
$runtime = Join-Path $project 'vendor\webview2\MicrosoftEdgeWebView2RuntimeInstallerX64.exe'
Invoke-WebRequest -Uri 'https://go.microsoft.com/fwlink/p/?LinkId=2124701' -OutFile $runtime
$signature = Get-AuthenticodeSignature $runtime
if ($signature.Status -ne 'Valid' -or $signature.SignerCertificate.Subject -notmatch 'CN=Microsoft Corporation') {
    throw 'WebView2 installer does not have a valid Microsoft signature'
}
Run-Python -Parameters @('-m','PyInstaller','--noconfirm','--clean','windows_desktop/wechatemoji-windows.spec')
$iscc = Join-Path ${env:ProgramFiles(x86)} 'Inno Setup 6\ISCC.exe'
if (-not (Test-Path $iscc)) { throw 'Inno Setup 6 is required on the Windows builder' }
& $iscc windows_desktop\installer.iss
if ($LASTEXITCODE -ne 0) { throw 'Installer compilation failed' }
$setup = (Get-ChildItem release\*-Setup.exe | Select-Object -First 1).FullName
$installed = Join-Path $env:TEMP 'Wechat Emoji Installed Test'
$install = Start-Process $setup -ArgumentList @('/VERYSILENT','/SUPPRESSMSGBOXES','/NORESTART',"/DIR=`"$installed`"") -PassThru
if (-not $install.WaitForExit(180000)) { Stop-Process $install.Id -Force; throw 'Installation timeout' }
if ($install.ExitCode -notin @(0,3010)) { throw "Installation failed: $($install.ExitCode)" }
$exe = Join-Path $installed 'wechatemoji.exe'
if (-not (Test-Path $exe)) { throw 'Installed application missing' }
$originalPath = $env:PATH
$originalLocalAppData = $env:LOCALAPPDATA
try {
    $env:PATH = "$env:SystemRoot\System32;$env:SystemRoot"
    $env:LOCALAPPDATA = Join-Path $env:TEMP 'Wechat Emoji Isolated Data'
    Remove-Item Env:PYTHONPATH -ErrorAction SilentlyContinue
    Remove-Item Env:PLAYWRIGHT_BROWSERS_PATH -ErrorAction SilentlyContinue
    foreach ($test in @('self-test','ui-smoke')) {
        $report = Join-Path $project "evidence\$test.json"
        $app = Start-Process $exe -WorkingDirectory $env:TEMP -ArgumentList @("--$test","`"$report`"") -PassThru
        if (-not $app.WaitForExit(120000)) { Stop-Process $app.Id -Force; throw "$test timed out" }
        if ($app.ExitCode -ne 0) { throw "$test process failed: $($app.ExitCode)" }
        $result = Get-Content $report -Raw | ConvertFrom-Json
        if ($result.status -ne 'passed') { throw "$test report failed" }
    }
} finally {
    $env:PATH = $originalPath
    $env:LOCALAPPDATA = $originalLocalAppData
}
$manifest = @{
    version='0.1.8'; arch='x64'; windows_build_and_install='passed';
    commit=$env:GITHUB_SHA; no_external_python_path=$true; no_development_path=$true;
    real_wechat_export_tested=$false; real_feishu_upload_tested=$false;
    webview2_sha256=(Get-FileHash $runtime -Algorithm SHA256).Hash;
    webview2_signer=$signature.SignerCertificate.Subject;
    installer_sha256=(Get-FileHash $setup -Algorithm SHA256).Hash;
    installer_bytes=(Get-Item $setup).Length;
    signed_application=$false
}
$manifest | ConvertTo-Json -Depth 5 | Set-Content evidence\build-manifest.json -Encoding utf8
(Get-FileHash $setup -Algorithm SHA256).Hash + '  ' + (Split-Path $setup -Leaf) | Set-Content release\SHA256SUMS.txt -Encoding utf8

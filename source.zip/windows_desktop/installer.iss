#define Version "0.1.8"
[Setup]
AppId={{414C1CF0-D05E-4900-8B72-811341FC0D32}
AppName=微信表情搬家
AppVersion={#Version}
DefaultDirName={localappdata}\Programs\WeChatEmoji
DefaultGroupName=微信表情搬家
PrivilegesRequired=lowest
ArchitecturesAllowed=x64os
ArchitecturesInstallIn64BitMode=x64os
MinVersion=10.0.19041
DisableDirPage=yes
DisableProgramGroupPage=yes
OutputDir=..\release
OutputBaseFilename=微信表情搬家-Windows-x64-v{#Version}-Setup
SetupIconFile=..\tauri_app\src-tauri\icons\icon.ico
UninstallDisplayIcon={app}\wechatemoji.exe
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
CloseApplications=yes
[Files]
Source: "..\dist\wechatemoji\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "..\vendor\webview2\MicrosoftEdgeWebView2RuntimeInstallerX64.exe"; Flags: dontcopy
[Icons]
Name: "{autoprograms}\微信表情搬家"; Filename: "{app}\wechatemoji.exe"
Name: "{autodesktop}\微信表情搬家"; Filename: "{app}\wechatemoji.exe"
[Run]
Filename: "{app}\wechatemoji.exe"; Description: "打开微信表情搬家"; Flags: nowait postinstall skipifsilent
[Code]
function WebViewInstalled: Boolean;
var Version: String;
begin
  Result := (RegQueryStringValue(HKCU, 'Software\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}', 'pv', Version) and (Version <> '') and (Version <> '0.0.0.0'));
  if not Result then
    Result := (RegQueryStringValue(HKLM32, 'Software\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}', 'pv', Version) and (Version <> '') and (Version <> '0.0.0.0'));
end;
function PrepareToInstall(var NeedsRestart: Boolean): String;
var Code: Integer;
begin
  Result := '';
  if not WebViewInstalled then begin
    ExtractTemporaryFile('MicrosoftEdgeWebView2RuntimeInstallerX64.exe');
    if not Exec(ExpandConstant('{tmp}\MicrosoftEdgeWebView2RuntimeInstallerX64.exe'), '/silent /install', '', SW_HIDE, ewWaitUntilTerminated, Code) then
      Result := '无法启动界面组件安装程序。请关闭其他安装程序后重试。'
    else if (Code <> 0) and (Code <> 3010) then
      Result := '界面组件安装失败。请重启电脑后重新运行本安装包。'
    else if not WebViewInstalled then
      Result := '没有检测到已安装的界面组件。请重启电脑后重新运行本安装包。';
    if Code = 3010 then NeedsRestart := True;
  end;
end;

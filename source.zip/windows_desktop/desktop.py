"""Windows composition root for the shared extraction and personal-import UI."""
from pathlib import Path

import webview
from simple_desktop import SimpleApi
from windows_paths import data_roots, remember, resolve_selection

import config
import wechat_extractor


def windows_html(source):
    replacements = {
        'Apple Silicon Mac · v0.1.7 本地试用版': 'Windows x64 · v0.1.8 试用版',
        '保存到你的 Mac。': '保存到你的电脑。',
        '首次导出：先退出微信，再点“导出”。弹出微信副本后，用手机确认登录；完成后重新打开原版微信。':
            '导出前请先打开并登录 Windows 微信，保持微信运行。若提示进程权限不足，可右键应用选择“以管理员身份运行”。',
        '首次使用请先退出微信。导出时弹出的微信，需要用手机确认登录。':
            '请保持 Windows 微信已登录并运行，然后点击下方导出。',
        '如果弹出微信，请用手机确认登录。': '正在读取已登录微信的表情，请保持微信运行。',
        '先完全退出微信后重试；弹出微信副本时，请在手机上确认登录。':
            '请保持微信已登录并运行。若提示无法读取进程，可右键应用选择“以管理员身份运行”后重试。',
        '首次使用请先退出微信，导出时用手机确认登录。': '请保持 Windows 微信已登录并运行。',
    }
    for old, new in replacements.items():
        source = source.replace(old, new)
    return source


class WindowsApi(SimpleApi):
    def browseWechatDir(self):
        selected = self.window.create_file_dialog(webview.FOLDER_DIALOG)
        if not selected:
            return
        try:
            root = resolve_selection(selected[0])
            remember(root)
            config.WECHAT_FILES_ROOT = str(root)
            self.detectWechat()
        except (OSError, ValueError) as exc:
            self._emit('wechatStatus', {'tone': 'error', 'code': 'data_missing',
                       'title': '没有找到微信数据', 'detail': str(exc)})


def create_app():
    # The platform adapter supplies discovery; extraction and decryption remain shared.
    config.WECHAT_FILES_ROOT = ''
    wechat_extractor.wechat_data_roots = data_roots
    api = WindowsApi()
    source = Path(config.APP_DIR) / 'simple_web/index.html'
    if not source.is_file():
        source = Path(__file__).resolve().parents[1] / 'macos_desktop/simple_web/index.html'
    api.window = webview.create_window('微信表情搬家', html=windows_html(source.read_text(encoding='utf-8')),
        js_api=api, width=960, height=800, min_size=(720, 650), text_select=False)
    api.window.events.closing += api._shutdown_import
    return api

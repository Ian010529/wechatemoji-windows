"""Windows composition root for the shared extraction and personal-import UI."""
import json
import re
import tempfile
from datetime import UTC, datetime
from pathlib import Path

import webview
from simple_desktop import SimpleApi
from windows_paths import data_roots, remember, resolve_selection

import bridge_common
import config
import wechat_extractor


def process_details():
    details = {}
    try:
        import ctypes

        import psutil
        import win32api

        from key_extractor import find_wechat_pid

        details['administrator'] = bool(ctypes.windll.shell32.IsUserAnAdmin())
        details['pid'] = find_wechat_pid()
        if details['pid']:
            executable = psutil.Process(details['pid']).exe()
            version = win32api.GetFileVersionInfo(executable, '\\')
            ms, ls = version['FileVersionMS'], version['FileVersionLS']
            details['wechat_version'] = f'{ms >> 16}.{ms & 65535}.{ls >> 16}.{ls & 65535}'
    except Exception as exc:
        details['query_error'] = type(exc).__name__
    return details


def windows_html(source):
    replacements = {
        'Apple Silicon Mac · v0.1.7 本地试用版': 'Windows x64 · v0.1.9 诊断版',
        '保存到你的 Mac。': '保存到你的电脑。',
        '首次导出：先退出微信，再点“导出”。弹出微信副本后，用手机确认登录；完成后重新打开原版微信。':
            '导出前请先打开并登录 Windows 微信，保持微信运行。若提示进程权限不足，可右键应用选择“以管理员身份运行”。',
        '首次使用请先退出微信。导出时弹出的微信，需要用手机确认登录。':
            '请保持 Windows 微信已登录并运行，然后点击下方导出。',
        '如果弹出微信，请用手机确认登录。': '正在读取已登录微信的表情，请保持微信运行。',
        '先完全退出微信后重试；弹出微信副本时，请在手机上确认登录。':
            '请保持微信已登录并运行。若提示无法读取进程，可右键应用选择“以管理员身份运行”后重试。',
        '首次使用请先退出微信，导出时用手机确认登录。': '请保持 Windows 微信已登录并运行。',
        '<pre id="logs">': '<button id="diagnostics" disabled onclick="api.openExportDiagnostics()">打开导出诊断</button><pre id="logs">',
        'function ready(){': "function ready(){el('diagnostics').disabled=!api||busy;",
        'function failure(message){': "function failure(message){document.querySelector('details').open=true;",
    }
    for old, new in replacements.items():
        source = source.replace(old, new)
    return source


class WindowsApi(SimpleApi):
    def startExtract(self, raw_payload=None):
        if self._busy:
            return
        self._export_report = {'schema_version': 1, 'started_at': datetime.now(UTC).isoformat(),
            'status': 'running', 'process': process_details(), 'messages': []}
        self._save_export_report()
        super().startExtract(raw_payload)
        if not self._busy and self._export_report['status'] == 'running':
            self._export_report['status'] = 'rejected'
            self._save_export_report()

    def _save_export_report(self):
        target = Path(config.DATA_DIR) / 'logs/latest-export.json'
        temporary = None
        try:
            target.parent.mkdir(parents=True, exist_ok=True)
            with tempfile.NamedTemporaryFile(mode='w', encoding='utf-8', dir=target.parent, delete=False) as stream:
                temporary = Path(stream.name)
                json.dump(self._export_report, stream, ensure_ascii=False, indent=2)
            temporary.replace(target)
        except OSError:
            pass  # Diagnostics must not prevent extraction.
        finally:
            if temporary:
                try:
                    temporary.unlink(missing_ok=True)
                except OSError:
                    pass

    def _log(self, message, level='info'):
        report = getattr(self, '_export_report', None)
        if report and report['status'] == 'running':
            safe = re.sub(r'wxid_[\w-]+', '[微信账号]', str(message))
            safe = re.sub(r'[0-9a-fA-F]{32,}', '[校验值已隐藏]', safe)
            report['messages'].append({'level': level, 'message': safe})
            self._save_export_report()
        super()._log(message, level)

    def _on_extract_progress(self, current, total, message):
        if total <= 0:
            level = 'error' if message.startswith('[错误]') else 'warn' if message.startswith('[警告]') else 'info'
            self._log(message, level)
        else:
            super()._on_extract_progress(current, total, message)

    def _on_extract_done(self, files):
        report = getattr(self, '_export_report', None)
        if report:
            messages = [row['message'] for row in report['messages']]
            if not files:
                if any('无法打开进程' in message for message in messages):
                    reason = '未能读取微信进程。请确认微信仍在运行；若已经使用管理员方式，点“打开导出诊断”查看本次记录。'
                elif any('未找到密钥' in message or '密钥提取失败' in message for message in messages):
                    reason = '扫描已完成，但没有取得当前表情数据库的密钥，本地缓存也未能导出。请在微信打开“表情 → 收藏”，等加载后重试；仍失败时点“打开导出诊断”。'
                else:
                    reason = next((row['message'] for row in reversed(report['messages']) if row['level'] == 'error'),
                        '本次没有导出可用图片。请点“打开导出诊断”查看完整阶段记录。')
                self._log(reason, 'error')
                report['reason'] = reason
            report.update(status='passed' if files else 'failed', exported_count=len(files))
            self._save_export_report()
        super()._on_extract_done(files)

    def openExportDiagnostics(self):
        folder = Path(config.DATA_DIR) / 'logs'
        folder.mkdir(parents=True, exist_ok=True)
        bridge_common.open_folder(str(folder))

    def browseWechatDir(self):
        selected = self.window.create_file_dialog(webview.FOLDER_DIALOG)
        if not selected:
            return
        try:
            root = resolve_selection(selected[0])
            remember(root)
            config.WECHAT_FILES_ROOT = str(root)
            self.detectWechat()
        except (OSError, ValueError) as exc:
            self._emit('wechatStatus', {'tone': 'error', 'code': 'data_missing',
                       'title': '没有找到微信数据', 'detail': str(exc)})


def create_app():
    # The platform adapter supplies discovery; extraction and decryption remain shared.
    config.WECHAT_FILES_ROOT = ''
    wechat_extractor.wechat_data_roots = data_roots
    api = WindowsApi()
    source = Path(config.APP_DIR) / 'simple_web/index.html'
    if not source.is_file():
        source = Path(__file__).resolve().parents[1] / 'macos_desktop/simple_web/index.html'
    api.window = webview.create_window('微信表情搬家', html=windows_html(source.read_text(encoding='utf-8')),
        width=960, height=800, min_size=(720, 650), text_select=False)
    api.window.expose(api.simpleInit, api.detectWechat, api.browseWechatDir, api.startExtract,
        api.openOutputDir, api.startSmartImport, api.stopSmartImport, api.prepareCleanup,
        api.confirmCleanup, api.createBatches, api.openExportDiagnostics)
    api.window.events.closing += api._shutdown_import
    return api

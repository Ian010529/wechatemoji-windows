"""Frozen Windows entry; diagnostics never read WeChat or real login data."""
import ctypes
import json
import sys
import threading
import time
from pathlib import Path


def ui_smoke(api, output):
    def check():
        result = {'status': 'failed', 'test': 'frozen WebView2 UI'}
        try:
            deadline = time.monotonic() + 30
            while time.monotonic() < deadline:
                ready = api.window.evaluate_js("typeof api!=='undefined' && !!api && !document.getElementById('cleanup').disabled")
                if ready:
                    result = {'status': 'passed', 'test': 'frozen WebView2 UI',
                              'user_agent': api.window.evaluate_js('navigator.userAgent')}
                    break
                time.sleep(0.2)
        except Exception as exc:
            result['error'] = type(exc).__name__
        finally:
            Path(output).write_text(json.dumps(result, indent=2), encoding='utf-8')
            api.window.destroy()
    threading.Thread(target=check, daemon=True).start()


def main():
    if '--self-test' in sys.argv:
        from smoke_test import run
        run(Path(sys.argv[sys.argv.index('--self-test') + 1]))
        return
    import webview
    from desktop import create_app

    api = create_app()
    if '--ui-smoke' in sys.argv:
        destination = sys.argv[sys.argv.index('--ui-smoke') + 1]
        api.window.events.loaded += lambda: ui_smoke(api, destination)
    webview.start(gui='edgechromium', debug=False)


def execute():
    try:
        main()
    except Exception as error:
        for flag in ('--self-test', '--ui-smoke'):
            if flag in sys.argv:
                import traceback

                destination = Path(sys.argv[sys.argv.index(flag) + 1])
                destination.parent.mkdir(parents=True, exist_ok=True)
                destination.write_text(json.dumps({'status': 'failed', 'error': type(error).__name__,
                    'traceback': traceback.format_exc()}, ensure_ascii=False, indent=2), encoding='utf-8')
                raise SystemExit(1) from error
        ctypes.windll.user32.MessageBoxW(None,
            f'应用没能启动（{type(error).__name__}）。请重新运行安装程序修复界面组件。', '微信表情搬家', 0x10)
        raise SystemExit(1) from error


if __name__ == '__main__':
    execute()

"""Synthetic frozen-runtime acceptance; never opens real WeChat or Feishu."""
import base64
import hashlib
import http.server
import json
import sys
import tempfile
import threading
from contextlib import closing
from io import BytesIO
from pathlib import Path

from PIL import Image
from playwright.sync_api import sync_playwright
from smart_import import SmartImporter, browser_executable

HTML = b'''<!doctype html><meta charset="utf-8"><input type="file" multiple hidden>
<button class="add-sticker-btn">+</button><div id="images"></div><script>
window.received=JSON.parse(localStorage.received||'[]');
window.stored=JSON.parse(localStorage.images||'[]');
function render(src){let d=document.createElement('div');d.className='customized-sticker-item';let i=document.createElement('img');i.src=src;d.append(i);document.querySelector('#images').append(d)}
window.stored.forEach(render);
document.querySelector('button').onclick=()=>document.querySelector('input').click();
document.querySelector('input').onchange=async e=>{let fs=[...e.target.files];window.received.push(fs.length);localStorage.received=JSON.stringify(window.received);for(let f of fs){let src=await new Promise(r=>{let reader=new FileReader();reader.onload=()=>r(reader.result);reader.readAsDataURL(f)});window.stored.push(src);render(src)}localStorage.images=JSON.stringify(window.stored)};
const original=window.fetch.bind(window);window.fetch=async(...args)=>{if(window.received.length&&!localStorage.delayed){localStorage.delayed='1';throw new TypeError('synthetic delay')}return original(...args)};
</script>'''


class Handler(http.server.BaseHTTPRequestHandler):
    def log_message(self, *_args):
        pass

    def do_GET(self):
        self.send_response(200)
        self.send_header('Content-Type', 'text/html; charset=utf-8')
        self.end_headers()
        self.wfile.write(HTML)


def run(output):
    output = Path(output)
    result = {'status': 'failed', 'synthetic_only': True}
    engine = SmartImporter()
    server = http.server.ThreadingHTTPServer(('127.0.0.1', 0), Handler)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    try:
        with tempfile.TemporaryDirectory() as directory, closing(engine):
            driver = sync_playwright().start()
            engine._playwright_driver = driver
            engine._context = driver.chromium.launch_persistent_context(str(Path(directory) / 'profile'),
                executable_path=browser_executable(), headless=True)
            engine._page = engine._context.pages[0]
            engine._page.goto(f'http://127.0.0.1:{server.server_port}/')
            files = []
            for number in range(101):
                path = Path(directory) / f'{number}.gif'
                frames = [Image.new('RGB', (20, 20), (number, color, 0)) for color in (0, 80, 200)]
                frames[0].save(path, save_all=True, append_images=frames[1:], duration=[60, 120, 180], loop=2)
                files.append(str(path))
            first = engine.upload(files, lambda: False)
            assert len(first['added']) == 101 and not first['unconfirmed'], first
            assert engine._page.evaluate('window.received') == [50, 50, 1]
            second = engine.upload(files, lambda: False)
            assert len(second['already']) == 101 and not second['added'] and not second['unconfirmed'], second
            assert engine._page.evaluate('window.received') == [50, 50, 1]
            assert engine._page.evaluate('localStorage.delayed') == '1'
            blobs = engine._page.evaluate('window.stored')
            for raw in blobs:
                with Image.open(BytesIO(base64.b64decode(raw.split(',', 1)[1]))) as image:
                    assert image.n_frames == 3
            imports = {}
            for name in ('PIL', 'Crypto', 'webview', 'playwright'):
                module = __import__(name)
                imports[name] = str(Path(module.__file__).resolve())
                if getattr(sys, 'frozen', False):
                    assert Path(module.__file__).resolve().is_relative_to(Path(sys._MEIPASS).resolve()), imports
            result = {'status': 'passed', 'synthetic_only': True, 'batches': [50, 50, 1],
                'animated_verified': 101, 'frames_each': 3, 'repeat_submissions': 0,
                'transient_load_failure_recovered': engine._page.evaluate('localStorage.delayed') == '1',
                'browser': browser_executable(), 'frozen': bool(getattr(sys, 'frozen', False)),
                'dependency_origins': imports,
                'source_hash': hashlib.sha256(Path(__file__).read_bytes()).hexdigest() if not getattr(sys, 'frozen', False) else None}
    except Exception as exc:
        result['error'] = f'{type(exc).__name__}: {exc}'
        raise
    finally:
        engine.close()
        server.shutdown()
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')

"""AI-drafted offline regressions: no Windows account, process or credentials."""
import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import windows_paths
from desktop import windows_html
from smart_import import browser_executable

import config
import wechat_extractor


def account(root):
    result = root / 'wxid_synthetic'
    db = result / 'db_storage/emoticon/emoticon.db'
    db.parent.mkdir(parents=True)
    db.write_bytes(b'not a real database')
    return result


class WindowsTests(unittest.TestCase):
    def test_windows_browser_runtime_used_without_macos_or_headless_shell(self):
        for layout in ('chrome-win64', 'chrome-win'):
            with self.subTest(layout=layout), tempfile.TemporaryDirectory() as directory:
                executable = Path(directory) / f'chromium-123/{layout}/chrome.exe'
                executable.parent.mkdir(parents=True)
                executable.touch()
                with patch('smart_import.sys.platform', 'win32'), patch.object(sys, 'frozen', True, create=True), patch.object(config, 'PLAYWRIGHT_BUNDLE_DIR', directory):
                    self.assertEqual(browser_executable(), str(executable))
                    executable.unlink()
                    with self.assertRaisesRegex(RuntimeError, '浏览器组件不完整'):
                        browser_executable()

    def test_frozen_diagnostic_failure_writes_report_instead_of_showing_modal(self):
        import importlib.util

        spec = importlib.util.spec_from_file_location('windows_entry', Path(__file__).parent / 'main.py')
        entry = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(entry)
        with tempfile.TemporaryDirectory() as directory:
            report = Path(directory) / 'failed.json'
            with patch.object(entry, 'main', side_effect=RuntimeError('synthetic')), patch.object(sys, 'argv', ['wechatemoji', '--self-test', str(report)]):
                with self.assertRaises(SystemExit) as stopped:
                    entry.execute()
            self.assertEqual(stopped.exception.code, 1)
            self.assertEqual(json.loads(report.read_text())['status'], 'failed')

    def test_redirected_documents_and_explicit_selection_precedence(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            custom = root / 'D盘 中文/自选数据'
            account(custom)
            docs = root / 'OneDrive/Documents'
            with patch.object(config, 'WECHAT_FILES_ROOT', str(custom)), patch.object(config, 'DATA_DIR', str(root)), patch.object(windows_paths, 'documents_directory', return_value=docs):
                roots = windows_paths.data_roots()
                self.assertEqual(roots[0], str(custom))
                self.assertIn(str(docs / 'xwechat_files'), roots)

    def test_account_root_and_adjacent_selection_resolve_same_root(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            user = account(root)
            for selected in (root, user, user / 'db_storage'):
                self.assertEqual(windows_paths.resolve_selection(selected), root.resolve())
            with self.assertRaises(ValueError):
                windows_paths.resolve_selection(root / 'missing')

    def test_saved_location_is_strict_and_invalid_path_not_reused(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            custom = root / 'custom'
            account(custom)
            with patch.object(config, 'DATA_DIR', str(root)):
                windows_paths.remember(custom)
                self.assertEqual(windows_paths.selected_root(), custom)
                (root / 'windows-location.json').write_text(json.dumps({'data_root': str(custom), 'extra': True}))
                self.assertIsNone(windows_paths.selected_root())

    def test_extractor_reads_adapter_roots_without_assuming_home_documents(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            user = account(root)
            with patch.object(wechat_extractor, 'wechat_data_roots', return_value=[str(root)]), patch('key_extractor.find_wechat_pid', return_value=0), patch('wechat_extractor.sys.platform', 'win32'):
                infos = wechat_extractor.get_wechat_info()
                self.assertEqual(infos[0]['wx_dir'], str(user))
                self.assertFalse(infos[0]['running'])

    def test_windows_ui_preserves_login_and_animation_controls_without_mac_instructions(self):
        source = (Path(__file__).parents[1] / 'macos_desktop/simple_web/index.html').read_text()
        rendered = windows_html(source)
        for text in ('Apple Silicon', '你的 Mac', '先退出微信', '微信副本', '完全退出微信'):
            self.assertNotIn(text, rendered)
        for text in ('Windows x64', '请保持 Windows 微信已登录', '继续核对并导入', 'cleanupPreview'):
            self.assertIn(text, rendered)


if __name__ == '__main__':
    unittest.main()

from pathlib import Path
from PyInstaller.utils.hooks import collect_all

project = Path(SPECPATH).parent
extras_data, extras_binaries, extras_imports = collect_all('pywxdump')
runtime = project / 'vendor/ms-playwright'
if not list(runtime.glob('chromium-*/chrome-win*/chrome.exe')):
    raise RuntimeError('Missing bundled Windows Chromium')
a = Analysis([str(project / 'windows_desktop/main.py')],
    pathex=[str(project), str(project / 'macos_desktop'), str(project / 'windows_desktop')],
    binaries=extras_binaries,
    datas=[(str(project / 'macos_desktop/simple_web'), 'simple_web'),
           (str(runtime), 'runtime/ms-playwright'),
           (str(project / 'vendor/licenses'), 'licenses'), (str(project / 'LICENSE'), '.')]+extras_data,
    hiddenimports=['gui', 'simple_desktop', 'smart_import', 'sticker_cleanup', 'windows_paths',
        'desktop', 'smoke_test', 'webview.platforms.winforms', 'webview.platforms.edgechromium']+extras_imports,
    excludes=['tkinter', 'PyQt5', 'PySide6', 'webview.platforms.cocoa'], noarchive=False)
pyz = PYZ(a.pure)
exe = EXE(pyz, a.scripts, [], exclude_binaries=True, name='wechatemoji', console=False,
    icon=str(project / 'tauri_app/src-tauri/icons/icon.ico'), upx=False)
coll = COLLECT(exe, a.binaries, a.datas, strip=False, upx=False, name='wechatemoji')

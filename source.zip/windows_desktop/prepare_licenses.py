"""Collect installed dependency notices for distribution; build-time only."""
from importlib import metadata
from pathlib import Path

root = Path(__file__).resolve().parents[1] / 'vendor/licenses'
root.mkdir(parents=True, exist_ok=True)
for distribution in metadata.distributions():
    name = distribution.metadata['Name']
    if not name:
        continue
    destination = root / name
    destination.mkdir(exist_ok=True)
    for item in distribution.files or []:
        if any(word in item.name.lower() for word in ('license', 'copying', 'notice')):
            source = Path(distribution.locate_file(item))
            if source.is_file():
                # Preserve nested paths so different license notices cannot overwrite each other.
                safe = Path(*[part for part in item.parts if part not in ('..', '.')])
                target = destination / safe
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(source.read_bytes())

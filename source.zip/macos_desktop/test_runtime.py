"""AI-drafted regression: the share package needs only its full browser."""
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from smart_import import SmartImporter, browser_executable


class BundledRuntimeTests(unittest.TestCase):
    def test_full_browser_without_headless_shell_is_used_and_missing_runtime_fails(self):
        with tempfile.TemporaryDirectory() as directory:
            executable = Path(directory) / (
                'chromium-1248/chrome-mac-arm64/Google Chrome for Testing.app/'
                'Contents/MacOS/Google Chrome for Testing')
            executable.parent.mkdir(parents=True)
            executable.touch()
            with patch('smart_import.sys.platform', 'darwin'), \
                    patch('config.PLAYWRIGHT_BUNDLE_DIR', directory), \
                    patch('config.DATA_DIR', directory), \
                    patch.object(sys, 'frozen', True, create=True), \
                    patch('smart_import.sync_playwright') as playwright:
                SmartImporter().start()
                launch = playwright.return_value.start.return_value.chromium.launch_persistent_context
                self.assertEqual(launch.call_args.kwargs['executable_path'], str(executable))
                self.assertEqual(launch.call_args.kwargs['user_data_dir'], str(Path(directory) / 'feishu-browser'))
                self.assertFalse(launch.call_args.kwargs['headless'])
                executable.unlink()
                with self.assertRaises(RuntimeError):
                    browser_executable()


if __name__ == '__main__':
    unittest.main()

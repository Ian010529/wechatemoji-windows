"""Exact-content cleanup of personal stickers, with backup and server re-scan."""
import base64
import hashlib
import json
import re
import uuid
from pathlib import Path

from playwright.sync_api import Error as BrowserError
from playwright.sync_api import TimeoutError as BrowserTimeoutError
from smart_import import SmartImporter

from emoji_export_state import write_export


def cleanup_hashes(report=None, folder=None):
    if folder is not None:
        from emoji_images import validate_image

        files = sorted(p for p in Path(folder).rglob('*') if p.is_file() and not p.is_symlink()
                       and p.suffix.lower() in {'.gif', '.png', '.jpg', '.jpeg', '.webp'})
        result = set()
        for path in files:
            raw = path.read_bytes()
            validate_image(raw)
            result.add(hashlib.sha256(raw).hexdigest())
    else:
        data = json.loads(Path(report).read_text(encoding='utf-8'))
        if not isinstance(data, dict) or not isinstance(data.get('files'), list):
            raise ValueError('旧导入记录格式不正确，请选择旧版导出的图片文件夹。')
        result = set()
        for row in data['files']:
            if not isinstance(row, dict):
                raise ValueError('旧导入记录包含无效项。')
            if row.get('status') not in {'added', 'already', 'verified_present'}:
                continue
            digest = row.get('sha256')
            if not isinstance(digest, str) or not re.fullmatch('[0-9a-f]{64}', digest):
                raise ValueError('旧导入记录的图片校验值不正确。')
            result.add(digest)
    if not result:
        raise ValueError('没有找到可用于匹配的旧导入图片；请保留旧导出文件或导入记录。')
    return result


class StickerCleaner(SmartImporter):
    def _scroll_stickers(self, reset=False):
        return self._page.evaluate('''reset => {
            const image=document.querySelector('.customized-sticker-item img');
            for(let el=image;el&&el!==document.body;el=el.parentElement){
                if(el.scrollHeight>el.clientHeight+10&&/auto|scroll/.test(getComputedStyle(el).overflowY)){
                    const before=el.scrollTop;el.scrollTop=reset?0:before+Math.max(100,el.clientHeight*.7);
                    return !reset&&el.scrollTop===before;
                }
            }return true;
        }''', reset)

    def _read_stickers(self, backup_hashes=()):
        return self._page.evaluate('''async wanted => {
            const targets=new Set(wanted);
            const cache=window.__wechatemojiHashes??=new Map();
            return await Promise.all(Array.from(document.querySelectorAll('.customized-sticker-item img')).map(async img=>{
                const immutable=/^(blob:|data:)/.test(img.src),cached=immutable?cache.get(img.src):null;
                const bytes=cached&&!targets.has(cached)?null:new Uint8Array(await(await fetch(img.src,{signal:AbortSignal.timeout(5000)})).arrayBuffer());
                const sha256=cached||Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes)),n=>n.toString(16).padStart(2,'0')).join('');
                if(immutable)cache.set(img.src,sha256);
                let data=null;
                if(targets.has(sha256)){
                    let binary='';for(let i=0;i<bytes.length;i+=32768)binary+=String.fromCharCode(...bytes.subarray(i,i+32768));
                    data=btoa(binary);
                }
                return {key:img.getAttribute('data-image-key'),sha256,data};
            }));
        }''', sorted(backup_hashes))

    def scan_stickers(self, stopped, targets=(), backup=None):
        self.open_personal_panel()
        self._scroll_stickers(True)
        self._page.wait_for_timeout(250)
        found = {}
        saved = set()
        for _ in range(200):
            if stopped():
                raise RuntimeError('已停止；未完成的扫描不能作为清理依据。')
            for row in self._read_stickers(set(targets) - saved):
                key, digest = row['key'], row['sha256']
                if not key or not re.fullmatch('[0-9a-f]{64}', digest):
                    raise RuntimeError('飞书图片标识不完整，已暂停清理。')
                if key in found and found[key] != digest:
                    raise RuntimeError('核对期间表情内容发生变化，请重新核对。')
                found[key] = digest
                if row['data'] is not None and backup is not None:
                    raw = base64.b64decode(row['data'], validate=True)
                    if hashlib.sha256(raw).hexdigest() != digest:
                        raise RuntimeError('图片备份校验失败，禁止删除。')
                    from wechat_extractor import detect_image_format

                    extension = detect_image_format(raw)
                    if not extension:
                        raise RuntimeError('无法识别备份图片，禁止删除。')
                    write_export(backup, digest, extension, raw)
                    saved.add(digest)
            if self._scroll_stickers():
                return found
            self._page.wait_for_timeout(180)
        raise RuntimeError('表情列表未核对完整，请重试。')

    def prepare_cleanup(self, targets, directory, stopped):
        targets = set(targets)
        if not targets or any(not re.fullmatch('[0-9a-f]{64}', value) for value in targets):
            raise ValueError('无效的清理来源。')
        token = uuid.uuid4().hex
        backup = Path(directory) / token
        backup.mkdir(parents=True, mode=0o700)
        self._report('正在按旧导入记录匹配，并备份命中的原图片。')
        before = self.scan_stickers(stopped, targets, backup)
        matched = {key: digest for key, digest in before.items() if digest in targets}
        plan = {'token': token, 'before': before, 'matched': matched, 'backup': str(backup),
                'source_hashes': sorted(targets), 'used': False}
        self._save_cleanup(plan, {'status': 'prepared'})
        return plan

    @staticmethod
    def _save_cleanup(plan, result):
        target = Path(plan['backup']) / 'cleanup.json'
        temporary = target.with_suffix('.tmp')
        temporary.write_text(json.dumps({'plan': plan, 'result': result}, ensure_ascii=False, indent=2), encoding='utf-8')
        temporary.chmod(0o600)
        temporary.replace(target)

    def delete_cleanup(self, plan, token, stopped):
        if token != plan['token'] or plan['used']:
            raise ValueError('清理确认已失效，请重新核对。')
        plan['used'] = True
        result = {'status': 'incomplete', 'attempted': [], 'clicked': [], 'confirmed_removed': [], 'error': ''}
        matched = plan['matched']
        try:
            now = self.scan_stickers(stopped)
            if now != plan['before']:
                raise RuntimeError('飞书收藏在核对后发生变化，请重新核对再确认。')
            # Check backup bytes immediately before any deletion.
            for digest in set(matched.values()):
                files = list(Path(plan['backup']).glob(digest + '.*'))
                if not files or hashlib.sha256(files[0].read_bytes()).hexdigest() != digest:
                    raise RuntimeError('清理备份丢失或被改动，禁止删除。')
            remaining = set(matched)
            last_wrap_count = -1
            last_refresh_count = -1
            self._scroll_stickers(True)
            self._page.wait_for_timeout(250)
            for _ in range(len(matched) + 200):
                if stopped() or not remaining:
                    break
                rows = self._read_stickers()
                row = next((row for row in rows if row['key'] in remaining), None)
                if row is None:
                    if self._scroll_stickers():
                        if len(result['clicked']) == last_wrap_count:
                            if len(result['clicked']) == last_refresh_count:
                                break
                            last_refresh_count = len(result['clicked'])
                            self._page.reload(wait_until='domcontentloaded')
                            self._page.wait_for_timeout(1000)
                            self.open_personal_panel()
                        last_wrap_count = len(result['clicked'])
                        self._scroll_stickers(True)
                        self._page.wait_for_timeout(250)
                        continue
                    self._page.wait_for_timeout(180)
                    continue
                key = row['key']
                if row['sha256'] != matched[key]:
                    raise RuntimeError('待删除表情内容变化，已停止。')
                image = self._page.locator('.customized-sticker-item img[data-image-key=' + json.dumps(key) + ']')
                if image.count() != 1:
                    raise RuntimeError('表情定位不唯一，已停止。')
                result['attempted'].append(key)
                self._save_cleanup(plan, result)
                for attempt in range(2):
                    if attempt:
                        current = next((item for item in self._read_stickers() if item['key'] == key), None)
                        if current is None:
                            break
                        if current['sha256'] != matched[key]:
                            raise RuntimeError('重试前表情内容变化，已停止。')
                    image.click(button='right')
                    menu = self._page.get_by_role('menuitem', name=re.compile(r'^删除\s*$'))
                    if menu.count() != 1:
                        raise RuntimeError('飞书删除入口发生变化，已停止。')
                    menu.click()
                    try:
                        image.wait_for(state='detached', timeout=10000)
                        break
                    except BrowserTimeoutError:
                        if attempt:
                            raise RuntimeError('飞书未确认删除，已暂停；请稍后重新核对。') from None
                        self._page.wait_for_timeout(1000)
                result['clicked'].append(key)
                remaining.remove(key)
                self._save_cleanup(plan, result)
                self._report(f'正在清理 {len(result["clicked"])}/{len(matched)} 张（包含重复项）…',
                             len(result['clicked']), len(matched))
                self._page.wait_for_timeout(1000)
        except (OSError, RuntimeError, BrowserError) as exc:
            result['error'] = str(exc)
        try:
            # Read fresh server state even after a timeout; optimistic UI changes are insufficient.
            if result['attempted']:
                self._page.reload(wait_until='domcontentloaded')
                self._page.wait_for_timeout(1000)
            final = self.scan_stickers(lambda: False)
            result['confirmed_removed'] = sorted(set(result['attempted']) - set(final))
            protected = {key: digest for key, digest in plan['before'].items() if key not in matched}
            result['protected_missing_or_changed'] = sorted(key for key, digest in protected.items()
                                                           if final.get(key) != digest)
            result['remaining'] = sorted(set(matched) & set(final))
            result['status'] = ('passed' if not result['remaining'] and not result['protected_missing_or_changed'] and not result['error']
                                else 'stopped' if stopped() else 'incomplete')
            result['final_count'] = len(final)
        except (OSError, RuntimeError, BrowserError) as exc:
            result['error'] = result['error'] or str(exc)
        self._save_cleanup(plan, result)
        return result

"""Small distribution entry point; reuse the existing extraction adapter."""
import json
import queue
import shutil
import sys
import tempfile
import threading
from datetime import UTC, datetime
from pathlib import Path
from subprocess import CalledProcessError

import webview
from playwright.sync_api import Error as BrowserError

import bridge_common
import config
from gui import Api


def group_images(files, destination):
    """Copy images into fresh groups of 50, preserving the originals."""
    files = sorted({Path(path) for path in files})
    if not files:
        raise ValueError("还没有表情，请先导出。")
    Path(destination).mkdir(parents=True, exist_ok=True)
    root = Path(tempfile.mkdtemp(prefix="飞书分组-", dir=destination))
    for index, source in enumerate(files):
        folder = root / f"第{index // 50 + 1:02d}组"
        folder.mkdir(exist_ok=True)
        shutil.copy2(source, folder / source.name)
    return root, (len(files) + 49) // 50


class SimpleApi(Api):
    def __init__(self):
        super().__init__()
        self._smart_jobs = queue.Queue()
        self._smart_stop = threading.Event()
        self._import_closed = threading.Event()
        self._cleanup_plan = None
        threading.Thread(target=self._import_worker, daemon=True).start()

    def startSmartImport(self):
        if self._busy or not self.emoji_files:
            return
        self._smart_stop.clear()
        self._set_busy(True, "upload")
        self._cleanup_plan = None
        self._smart_jobs.put(('import', list(self.emoji_files)))

    def prepareCleanup(self, choose_folder=False):
        if self._busy:
            return {'ok': False, 'message': '请先停止当前操作。'}
        try:
            from sticker_cleanup import cleanup_hashes

            source = Path(config.OUTPUT_DIR) / 'feishu-import-result.json'
            if choose_folder or not source.is_file():
                selected = self.window.create_file_dialog(webview.FOLDER_DIALOG)
                if not selected:
                    return {'ok': False, 'message': '未选择旧导出文件夹，未删除任何表情。'}
                hashes = cleanup_hashes(folder=selected[0])
                label = '所选旧导出图片'
            else:
                hashes = cleanup_hashes(report=source)
                label = '上次导入核验记录'
            self._cleanup_plan = None
            self._smart_stop.clear()
            self._set_busy(True, 'cleanup')
            self._smart_jobs.put(('prepare_cleanup', (hashes, label)))
            return {'ok': True}
        except (OSError, ValueError) as exc:
            return {'ok': False, 'message': str(exc)}

    def confirmCleanup(self, token):
        if self._busy or not self._cleanup_plan or token != self._cleanup_plan['token']:
            return {'ok': False, 'message': '清理确认已失效，请重新核对。'}
        self._smart_stop.clear()
        self._set_busy(True, 'cleanup')
        self._smart_jobs.put(('delete_cleanup', self._cleanup_plan))
        self._cleanup_plan = None
        return {'ok': True}

    def stopSmartImport(self):
        self._smart_stop.set()

    def _shutdown_import(self):
        self._smart_stop.set()
        self._smart_jobs.put(None)
        if not self._import_closed.wait(10):
            self._emit("importStatus", {"message": "正在结束导入，请稍后再关闭窗口。"})
            return False

    def _import_worker(self):
        from sticker_cleanup import StickerCleaner

        uploader = None
        while True:
            try:
                job = self._smart_jobs.get(timeout=0.1)
            except queue.Empty:
                if uploader:
                    try:
                        uploader._page.wait_for_timeout(100)
                    except BrowserError:
                        uploader.close()
                        uploader = None
                continue
            if job is None:
                if uploader:
                    uploader.close()
                self._import_closed.set()
                return
            mode, payload = job
            try:
                if uploader is None:
                    uploader = StickerCleaner(progress_callback=lambda current, total, message:
                        self._emit("importStatus", {"message": message, "current": current, "total": total}))
                    uploader.start()
                if mode != 'import':
                    if not uploader.wait_login(self._smart_stop.is_set):
                        raise RuntimeError('已停止清理。')
                    if mode == 'prepare_cleanup':
                        hashes, label = payload
                        self._cleanup_plan = uploader.prepare_cleanup(hashes,
                            Path(config.OUTPUT_DIR) / 'feishu-cleanup-backups', self._smart_stop.is_set)
                        plan = self._cleanup_plan
                        matched = plan['matched']
                        self._emit('cleanupPreview', {'token': plan['token'], 'matched': len(matched),
                            'unique': len(set(matched.values())), 'sourceCount': len(hashes), 'source': label,
                            'protected': len(plan['before']) - len(matched), 'backup': plan['backup']})
                    else:
                        result = uploader.delete_cleanup(payload, payload['token'], self._smart_stop.is_set)
                        self._emit('cleanupResult', {'removed': len(result['confirmed_removed']),
                            'ok': result['status'] == 'passed', 'error': result['error'],
                            'message': '清理完成，已重新核验其他收藏。' if result['status'] == 'passed'
                                       else '清理未全部确认，请重新核对；已保留备份和清理记录。'})
                    continue
                files = payload
                if uploader.wait_login(self._smart_stop.is_set):
                    result = uploader.upload(files, self._smart_stop.is_set)
                else:
                    result = {"added": [], "already": [], "unconfirmed": files, "stopped": True}
                from smart_import import image_hashes

                hashes = image_hashes(files)
                audit = {"checked_at": datetime.now(UTC).isoformat(),
                    "verification": result.get("verification"), "files": [
                        {"filename": Path(file).name, "sha256": hashes[file], "status": status}
                        for status in ("added", "already", "unconfirmed") for file in result[status]]}
                report = Path(config.OUTPUT_DIR) / "feishu-import-result.json"
                report.parent.mkdir(parents=True, exist_ok=True)
                report.write_text(json.dumps(audit, ensure_ascii=False, indent=2), encoding='utf-8')
                report.chmod(0o600)
                self._emit("importResult", {"added": len(result["added"]), "already": len(result["already"]),
                    "unconfirmed": len(result["unconfirmed"]), "stopped": result["stopped"],
                    "error": result.get("error", "")})
            except Exception as exc:
                # Keep the native worker alive even when a third-party library fails unexpectedly.
                message = ("飞书连接中断或浏览器已关闭。请检查网络后重试；已保存的会自动跳过。"
                    if isinstance(exc, BrowserError) else str(exc) if isinstance(exc, (OSError, RuntimeError)) else (
                    f"操作已暂停（{type(exc).__name__}）。请关闭并重新打开应用重试；已保存的表情会自动跳过。"))
                self._emit("log", {"level": "error", "message": message})
                if mode == 'import':
                    self._emit("importResult", {"added": 0, "already": 0, "unconfirmed": len(payload), "error": message})
                else:
                    self._cleanup_plan = None
                    self._emit('cleanupResult', {'removed': 0, 'ok': False, 'error': message})
                if uploader:
                    uploader.close()
                    uploader = None
            finally:
                self._set_busy(False, "")
                if self._smart_stop.is_set() and uploader:
                    uploader.close()
                    uploader = None

    def simpleInit(self):
        from emoji_export_state import verified_exports

        old_files = self._collect_emoji_files(config.EMOJI_OUTPUT_DIR)
        self.emoji_files = sorted(verified_exports(config.EMOJI_OUTPUT_DIR).values())
        return {"outputDir": config.EMOJI_OUTPUT_DIR, "count": len(self.emoji_files),
                "repairCount": len(set(old_files) - set(self.emoji_files))}

    def _on_extract_done(self, files):
        if not files:
            self._pause_event.set()
            self._paused = False
            self._set_busy(False, "")
            self._emit("exportResult", {"ok": False, "count": 0})
            return
        super()._on_extract_done(files)
        self._emit("exportResult", {"ok": True, "count": len(files)})
        self.openOutputDir()

    def createBatches(self):
        if self._busy:
            return {"ok": False, "message": "请等导出完成。"}
        try:
            root, count = group_images(self.emoji_files, config.OUTPUT_DIR)
            bridge_common.open_folder(str(root))
            return {"ok": True, "count": count, "message": f"已分成 {count} 组。飞书表情 → 爱心 → ＋，每次选一组。"}
        except (OSError, ValueError, CalledProcessError) as exc:
            return {"ok": False, "message": str(exc)}


def main():
    api = SimpleApi()
    web_root = Path(config.APP_DIR) if getattr(sys, "frozen", False) else Path(__file__).parent
    api.window = webview.create_window(
        "微信表情搬家", url=str(web_root / "simple_web" / "index.html"),
        js_api=api, width=960, height=800, min_size=(720, 650), text_select=False,
    )
    api.window.events.closing += api._shutdown_import
    webview.start(debug=False, gui="cocoa")


if __name__ == "__main__":
    main()

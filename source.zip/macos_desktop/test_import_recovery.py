"""AI-drafted offline upload regressions; no real service or credentials."""
import hashlib
import tempfile
import unittest
from pathlib import Path
from unittest.mock import Mock

from smart_import import SmartImporter


class ImportRecoveryTests(unittest.TestCase):
    def test_incomplete_initial_scan_prevents_any_submission(self):
        with tempfile.TemporaryDirectory() as directory:
            source = Path(directory) / "image.png"
            source.write_bytes(b"synthetic image")
            uploader = SmartImporter()
            uploader._page = Mock()
            uploader.open_personal_panel = Mock()
            uploader.scan_images = Mock(side_effect=RuntimeError("图片未加载完整"))
            result = uploader.upload([str(source)], lambda: False)
            self.assertEqual(result["added"], [])
            self.assertEqual(result["unconfirmed"], [str(source)])
            self.assertIn("未加载完整", result["error"])
            uploader._page.expect_file_chooser.assert_not_called()

    def test_later_failure_preserves_confirmed_first_batch(self):
        with tempfile.TemporaryDirectory() as directory:
            files = []
            hashes = set()
            for index in range(51):
                file = Path(directory) / f"{index}.png"
                file.write_bytes(str(index).encode())
                files.append(str(file))
                if index < 50:
                    hashes.add(hashlib.sha256(file.read_bytes()).hexdigest())
            uploader = SmartImporter()
            from unittest.mock import MagicMock
            uploader._page = MagicMock()
            uploader.open_personal_panel = Mock()
            uploader.scan_images = Mock(side_effect=[set(), hashes, RuntimeError("列表失效")])
            result = uploader.upload(files, lambda: False)
            self.assertEqual(result["added"], files[:50])
            self.assertEqual(result["unconfirmed"], files[50:])
            self.assertEqual(result["error"], "列表失效")

    def test_unreadable_image_during_scan_is_not_treated_as_absent(self):
        uploader = SmartImporter()
        uploader._page = Mock()
        uploader._page.evaluate.side_effect = [None] + [{"hashes": [None], "end": False}] * 5
        with self.assertRaisesRegex(RuntimeError, "仍未加载完整"):
            uploader.scan_images(lambda: False)

    def test_transient_load_failure_retries_this_viewport_without_resetting_scan(self):
        uploader = SmartImporter()
        uploader._page = Mock()
        digest = "a" * 64
        uploader._page.evaluate.side_effect = [None,
            {"hashes": [None, digest], "end": False}, {"hashes": [digest], "end": True}]
        self.assertEqual(uploader.scan_images(lambda: False), {digest})
        self.assertEqual(uploader._page.evaluate.call_count, 3)
        self.assertEqual(uploader._page.wait_for_timeout.call_args_list[-1].args, (500,))

    def test_stop_during_load_retry_does_not_wait_again(self):
        uploader = SmartImporter()
        uploader._page = Mock()
        uploader._page.evaluate.side_effect = [None, {"hashes": [None], "end": False}]
        self.assertEqual(uploader.scan_images(Mock(side_effect=[False, True])), set())
        uploader._page.wait_for_timeout.assert_called_once_with(300)

    def test_resume_submits_only_missing_files(self):
        from unittest.mock import MagicMock

        with tempfile.TemporaryDirectory() as directory:
            files = []
            for index in range(51):
                file = Path(directory) / f"{index}.png"
                file.write_bytes(str(index).encode())
                files.append(str(file))
            digests = [hashlib.sha256(Path(file).read_bytes()).hexdigest() for file in files]
            uploader = SmartImporter()
            uploader._page = MagicMock()
            uploader.open_personal_panel = Mock()
            uploader.scan_images = Mock(side_effect=[set(digests[:50]), {digests[50]}, set(digests)])
            result = uploader.upload(files, lambda: False)
            self.assertEqual(result["already"], files[:50])
            self.assertEqual(result["added"], files[50:])
            self.assertEqual(result["unconfirmed"], [])
            uploader._page.expect_file_chooser.return_value.__enter__.return_value.value.set_files.assert_called_once_with(files[50:])

    def test_login_timeout_keeps_waiting_for_actual_messenger_ui(self):
        from playwright.sync_api import TimeoutError as BrowserTimeoutError

        uploader = SmartImporter()
        uploader._page = Mock()
        uploader._page.goto.side_effect = BrowserTimeoutError('synthetic slow navigation')
        uploader._login_ready = Mock(side_effect=[False, False, True])
        uploader._save_session = Mock()
        self.assertTrue(uploader.wait_login(lambda: False))
        uploader._save_session.assert_called_once()

    def test_messenger_url_without_loaded_ui_is_not_login_ready(self):
        uploader = SmartImporter()
        uploader._page = Mock()
        uploader._is_logged_in = Mock(return_value=True)
        uploader._page.locator.return_value.count.return_value = 0
        self.assertFalse(uploader._login_ready())
        uploader._page.locator.return_value.count.return_value = 1
        self.assertTrue(uploader._login_ready())

    def test_cancel_before_login_does_not_navigate(self):
        uploader = SmartImporter()
        uploader._page = Mock()
        self.assertFalse(uploader.wait_login(lambda: True))
        uploader._page.goto.assert_not_called()

    def test_browser_error_is_actionable_and_never_claims_upload_success(self):
        from playwright.sync_api import Error as BrowserError

        with tempfile.TemporaryDirectory() as directory:
            file = Path(directory) / 'synthetic.png'
            file.write_bytes(b'synthetic')
            uploader = SmartImporter()
            uploader.open_personal_panel = Mock(side_effect=BrowserError('internal stack trace'))
            result = uploader.upload([str(file)], lambda: False)
            self.assertEqual(result['unconfirmed'], [str(file)])
            self.assertEqual(result['added'], [])
            self.assertIn('继续核对并导入', result['error'])
            self.assertNotIn('internal stack', result['error'])

    def test_browser_profile_is_closed_before_driver(self):
        uploader = SmartImporter()
        calls = Mock()
        uploader._context = calls.context
        uploader._playwright_driver = calls.driver
        uploader.close()
        self.assertEqual([call[0] for call in calls.mock_calls], ["context.close", "driver.stop"])


if __name__ == "__main__":
    unittest.main()

"""AI-drafted offline regressions; no credentials or real account mutations."""
import hashlib
import json
import queue
import tempfile
import threading
import unittest
from pathlib import Path
from unittest.mock import MagicMock, Mock, patch

from smart_import import SmartImporter
from sticker_cleanup import StickerCleaner, cleanup_hashes


class CleanupTests(unittest.TestCase):
    def test_chinese_cleanup_records_work_with_a_non_utf8_system_locale(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory) / '中文备份'
            root.mkdir()
            report = root / 'import.json'
            report.write_bytes(json.dumps({'files': [{'filename': '动图.gif', 'status': 'added',
                'sha256': 'a' * 64}]}, ensure_ascii=False).encode('utf-8'))
            with patch('io.text_encoding', side_effect=lambda encoding, *args: encoding or 'cp1252'):
                self.assertEqual(cleanup_hashes(report=report), {'a' * 64})
                StickerCleaner._save_cleanup({'backup': str(root)}, {'error': '中文错误'})
            saved = json.loads((root / 'cleanup.json').read_bytes().decode('utf-8'))
            self.assertEqual(saved['result']['error'], '中文错误')
            self.assertEqual(saved['plan']['backup'], str(root))

    def test_only_confirmed_import_rows_are_sources(self):
        with tempfile.TemporaryDirectory() as directory:
            report = Path(directory) / 'report.json'
            report.write_text(json.dumps({'files': [
                {'sha256': 'a' * 64, 'status': 'already'},
                {'sha256': 'b' * 64, 'status': 'added'},
                {'sha256': 'c' * 64, 'status': 'unconfirmed'},
                {'sha256': 'd' * 64, 'status': 'verified_present'}]}))
            self.assertEqual(cleanup_hashes(report=report), {'a' * 64, 'b' * 64, 'd' * 64})
            report.write_text('{"files":[{"status":"added","sha256":"bad"}]}')
            with self.assertRaises(ValueError):
                cleanup_hashes(report=report)

    def test_empty_and_corrupt_sources_do_not_enable_deletion(self):
        with tempfile.TemporaryDirectory() as directory:
            with self.assertRaises(ValueError):
                cleanup_hashes(folder=directory)
            (Path(directory) / 'bad.gif').write_bytes(b'GIF89a broken')
            with self.assertRaises(OSError):
                cleanup_hashes(folder=directory)

    def test_wrong_or_reused_confirmation_token_never_scans(self):
        cleaner = StickerCleaner()
        cleaner.scan_stickers = Mock()
        for plan, token in (({'token': 'right', 'used': False}, 'wrong'),
                            ({'token': 'right', 'used': True}, 'right')):
            with self.assertRaises(ValueError):
                cleaner.delete_cleanup(plan, token, lambda: False)
        cleaner.scan_stickers.assert_not_called()

    def test_changed_collection_and_missing_backup_prevent_clicks(self):
        for changed in (True, False):
            with self.subTest(changed=changed), tempfile.TemporaryDirectory() as directory:
                cleaner = StickerCleaner()
                before = {'target': hashlib.sha256(b'image').hexdigest()}
                plan = {'token': 'right', 'used': False, 'backup': directory,
                        'before': before, 'matched': before}
                cleaner.scan_stickers = Mock(return_value={} if changed else before)
                cleaner._page = Mock()
                result = cleaner.delete_cleanup(plan, 'right', lambda: False)
                self.assertTrue(result['error'])
                self.assertEqual(result['confirmed_removed'], [])
                cleaner._page.locator.assert_not_called()

    def test_stale_frontend_token_is_rejected(self):
        from simple_desktop import SimpleApi

        api = object.__new__(SimpleApi)
        api._busy = False
        api._cleanup_plan = {'token': 'current'}
        api._smart_jobs = Mock()
        self.assertFalse(api.confirmCleanup('stale')['ok'])
        api._smart_jobs.put.assert_not_called()

    def test_incremental_scan_stops_when_this_batch_is_found(self):
        uploader = SmartImporter()
        uploader._page = Mock()
        digest = 'a' * 64
        uploader._page.evaluate.side_effect = [None, {'hashes': [digest], 'end': False}]
        self.assertEqual(uploader.scan_images(lambda: False, until={digest}), {digest})
        self.assertEqual(uploader._page.evaluate.call_count, 2)

    def test_upload_has_initial_batch_and_one_final_scan(self):
        with tempfile.TemporaryDirectory() as directory:
            file = Path(directory) / 'image.gif'
            file.write_bytes(b'synthetic fixture only')
            digest = hashlib.sha256(file.read_bytes()).hexdigest()
            uploader = SmartImporter()
            uploader._page = MagicMock()
            uploader.open_personal_panel = Mock()
            uploader.scan_images = Mock(side_effect=[set(), {digest}, {digest}])
            result = uploader.upload([str(file)], lambda: False)
            self.assertEqual(result['added'], [str(file)])
            self.assertEqual(uploader.scan_images.call_count, 3)
            self.assertEqual(uploader.scan_images.call_args_list[1].kwargs['until'], {digest})
            uploader._page.reload.assert_called_once()

    def test_shrinking_virtual_list_wraps_without_repeating_full_scan(self):
        with tempfile.TemporaryDirectory() as directory:
            digests = [hashlib.sha256(value).hexdigest() for value in (b'a', b'b', b'other')]
            for digest, raw in zip(digests[:2], (b'a', b'b'), strict=True):
                (Path(directory) / (digest + '.png')).write_bytes(raw)
            before = dict(zip(('target-a', 'target-b', 'other'), digests, strict=True))
            cleaner = StickerCleaner()
            cleaner._page = MagicMock()
            cleaner._page.locator.return_value.count.return_value = 1
            cleaner._page.get_by_role.return_value.count.return_value = 1
            cleaner.scan_stickers = Mock(side_effect=[before, {'other': digests[2]}])
            cleaner._read_stickers = Mock(side_effect=[
                [{'key': 'target-a', 'sha256': digests[0]}],
                [{'key': 'other', 'sha256': digests[2]}],
                [{'key': 'target-b', 'sha256': digests[1]}]])
            cleaner._scroll_stickers = Mock(side_effect=[False, True, False])
            plan = {'token': 'valid', 'used': False, 'backup': directory, 'before': before,
                    'matched': {key: before[key] for key in ('target-a', 'target-b')}}
            result = cleaner.delete_cleanup(plan, 'valid', lambda: False)
            self.assertEqual(result['status'], 'passed')
            self.assertEqual(result['confirmed_removed'], ['target-a', 'target-b'])
            self.assertEqual(cleaner.scan_stickers.call_count, 2)
            self.assertEqual(cleaner._scroll_stickers.call_args_list[-1].args, (True,))

    def test_stale_list_refreshes_only_after_a_wrap_with_no_progress(self):
        with tempfile.TemporaryDirectory() as directory:
            digests = [hashlib.sha256(value).hexdigest() for value in (b'a', b'b', b'other')]
            for digest, raw in zip(digests[:2], (b'a', b'b'), strict=True):
                (Path(directory) / (digest + '.png')).write_bytes(raw)
            before = dict(zip(('a', 'b', 'other'), digests, strict=True))
            cleaner = StickerCleaner()
            cleaner._page = MagicMock()
            cleaner._page.locator.return_value.count.return_value = 1
            cleaner._page.get_by_role.return_value.count.return_value = 1
            cleaner.open_personal_panel = Mock()
            cleaner.scan_stickers = Mock(side_effect=[before, {'other': digests[2]}])
            cleaner._read_stickers = Mock(side_effect=[
                [{'key': 'a', 'sha256': digests[0]}],
                [{'key': 'other', 'sha256': digests[2]}],
                [{'key': 'other', 'sha256': digests[2]}],
                [{'key': 'b', 'sha256': digests[1]}]])
            cleaner._scroll_stickers = Mock(side_effect=[False, True, False, True, False])
            plan = {'token': 'valid', 'used': False, 'backup': directory, 'before': before,
                    'matched': {key: before[key] for key in ('a', 'b')}}
            result = cleaner.delete_cleanup(plan, 'valid', lambda: False)
            self.assertEqual(result['status'], 'passed')
            self.assertEqual(cleaner.scan_stickers.call_count, 2)
            self.assertEqual(cleaner._page.reload.call_count, 2)  # Recovery and final acceptance.
            cleaner.open_personal_panel.assert_called_once()

    def test_cleanup_worker_passes_a_callable_login_stop_check(self):
        from simple_desktop import SimpleApi

        api = object.__new__(SimpleApi)
        api._smart_jobs = queue.Queue()
        api._smart_stop = threading.Event()
        api._import_closed = threading.Event()
        api._emit = Mock()
        api._set_busy = Mock()
        api._smart_jobs.put(('prepare_cleanup', ({'a' * 64}, 'fixture')))
        api._smart_jobs.put(None)
        uploader = Mock()

        def login(stopped):
            self.assertTrue(callable(stopped))
            self.assertFalse(stopped())
            return True

        uploader.wait_login.side_effect = login
        uploader.prepare_cleanup.return_value = {'token': 'valid', 'matched': {}, 'before': {}, 'backup': 'fixture'}
        with patch('sticker_cleanup.StickerCleaner', return_value=uploader):
            api._import_worker()
        self.assertEqual(api._cleanup_plan['token'], 'valid')
        self.assertTrue(api._import_closed.is_set())

    def test_unexpected_failure_returns_error_and_worker_accepts_next_job(self):
        from simple_desktop import SimpleApi

        api = object.__new__(SimpleApi)
        api._smart_jobs = queue.Queue()
        api._smart_stop = threading.Event()
        api._import_closed = threading.Event()
        api._emit = Mock()
        api._set_busy = Mock()
        api._smart_jobs.put(('import', ['synthetic']))
        api._smart_jobs.put(('prepare_cleanup', ({'a' * 64}, 'fixture')))
        api._smart_jobs.put(None)
        uploader = Mock()
        uploader.wait_login.side_effect = [TypeError('synthetic'), True]
        uploader.prepare_cleanup.return_value = {'token': 'valid', 'matched': {}, 'before': {}, 'backup': 'fixture'}
        with patch('sticker_cleanup.StickerCleaner', return_value=uploader):
            api._import_worker()
        errors = [call.args[1] for call in api._emit.call_args_list if call.args[0] == 'importResult']
        self.assertEqual(len(errors), 1)
        self.assertIn('TypeError', errors[0]['error'])
        self.assertEqual(api._cleanup_plan['token'], 'valid')
        self.assertTrue(api._import_closed.is_set())


if __name__ == '__main__':
    unittest.main()

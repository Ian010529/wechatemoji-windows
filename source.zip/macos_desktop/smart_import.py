"""Personal Feishu import: batches of 50 with image-content verification."""
import hashlib
import json
import sys
import tempfile
import time
from pathlib import Path

from playwright.sync_api import Error as BrowserError
from playwright.sync_api import TimeoutError as BrowserTimeoutError
from playwright.sync_api import sync_playwright

import config
from feishu_uploader import FeishuUploader


def image_hashes(files):
    return {str(path): hashlib.sha256(Path(path).read_bytes()).hexdigest() for path in files}


def partition(files):
    return [files[index:index + 50] for index in range(0, len(files), 50)]


def browser_executable():
    root = Path(config.PLAYWRIGHT_BUNDLE_DIR)
    patterns = ('chromium-*/chrome-win64/chrome.exe', 'chromium-*/chrome-win/chrome.exe') if sys.platform == 'win32' else (
        'chromium-*/chrome-mac-arm64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing',)
    executable = next((path for pattern in patterns for path in sorted(root.glob(pattern)) if path.is_file()), None)
    if executable and executable.is_file():
        return str(executable)
    if getattr(sys, 'frozen', False):
        raise RuntimeError('浏览器组件不完整，请重新下载应用。')
    return None


class SmartImporter(FeishuUploader):
    def start(self):
        self._timeout_error = BrowserTimeoutError
        executable = browser_executable()
        profile = Path(config.DATA_DIR) / "feishu-browser"
        profile.mkdir(parents=True, exist_ok=True)
        profile.chmod(0o700)
        self._session_file = profile / "wechatemoji-session.json"
        self._playwright_driver = sync_playwright().start()
        self._context = self._playwright_driver.chromium.launch_persistent_context(
            user_data_dir=str(profile), headless=False, executable_path=executable,
            no_viewport=True, args=["--window-size=1280,900"])
        self._page = self._context.pages[0] if self._context.pages else self._context.new_page()
        self._page.set_default_timeout(5000)
        self._page.set_default_navigation_timeout(config.PAGE_TIMEOUT)
        try:
            state = json.loads(self._session_file.read_text(encoding='utf-8'))
            if not isinstance(state, dict) or set(state) != {"cookies"} or not isinstance(state["cookies"], list):
                raise ValueError("invalid cookie state")
            self._context.add_cookies(state["cookies"])
        except FileNotFoundError:
            pass
        except (OSError, ValueError, BrowserError):
            self._report("无法恢复上次的飞书登录，请在窗口中重新扫码。")

    def _save_session(self):
        target = getattr(self, "_session_file", None)
        if not target or not self._context:
            return
        temporary = None
        try:
            cookies = self._context.cookies()
            with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", dir=target.parent, delete=False) as stream:
                temporary = Path(stream.name)
                json.dump({"cookies": cookies}, stream)
            temporary.replace(target)
        except (OSError, BrowserError):
            self._report("未能保存飞书登录，下次打开可能需要重新扫码。")
        finally:
            if temporary:
                temporary.unlink(missing_ok=True)

    def close(self):
        if self._context:
            self._save_session()
            try:
                self._context.close()
            except BrowserError:
                pass
            self._context = None
        super().close()

    def _login_ready(self):
        return self._is_logged_in() and bool(self._page.locator(
            '.a11y_feed_card_item, [contenteditable="true"]').count())

    def wait_login(self, stopped):
        if stopped():
            return False
        if self._login_ready():
            self._report("已登录飞书，正在继续。")
            return True
        self._report("请在打开的飞书窗口中扫码登录。登录后会自动继续。")
        try:
            self._page.goto(config.FEISHU_MESSENGER_URL, wait_until="domcontentloaded")
        except BrowserTimeoutError:
            self._report("飞书页面加载较慢，正在继续等待。请检查网络；可点“停止”后重试。")
        except BrowserError as exc:
            raise RuntimeError("无法打开飞书。请检查网络后点“继续核对并导入”；已保存的不会重复添加。") from exc
        while not stopped():
            if self._login_ready():
                self._page.wait_for_timeout(1500)
                self._save_session()
                return True
            self._page.wait_for_timeout(500)
        return False

    def open_personal_panel(self):
        page = self._page
        if page.locator('.add-sticker-btn').first.is_visible():
            return
        editor = page.locator('[contenteditable="true"]')
        if not editor.count():
            cards = page.locator('.a11y_feed_card_item')
            cards.first.wait_for(state="visible", timeout=30000)
            for index in range(min(cards.count(), 12)):
                cards.nth(index).click()
                page.wait_for_timeout(600)
                if editor.count():
                    break
        if not editor.count():
            raise RuntimeError("没找到可输入消息的会话；请在飞书窗口选中一个普通会话后重试。")
        if not self._open_emoji_panel():
            raise RuntimeError("飞书表情入口发生变化，暂时无法自动导入。")

    def scan_images(self, stopped, until=()):
        """Hash decrypted image blobs, never transient blob URLs or chat text."""
        found = set()
        page = self._page
        page.evaluate("""() => {
            let node=document.querySelector('.customized-sticker-item img');
            for(let el=node;el&&el!==document.body;el=el.parentElement){
                if(el.scrollHeight>el.clientHeight+10&&/auto|scroll/.test(getComputedStyle(el).overflowY)){
                    el.scrollTop=0;break;
                }
            }
        }""")
        page.wait_for_timeout(300)
        for _ in range(160):
            if stopped():
                break
            for attempt in range(5):
                result = page.evaluate("""async () => {
                    const images=Array.from(document.querySelectorAll('.customized-sticker-item img'));
                    const cache=window.__wechatemojiHashes??=new Map();
                    const hashes=await Promise.all(images.map(async img=>{
                        try{
                            const immutable=/^(blob:|data:)/.test(img.src);
                            if(immutable&&cache.has(img.src))return cache.get(img.src);
                            const data=await (await fetch(img.src,{signal:AbortSignal.timeout(5000)})).arrayBuffer();
                            const hash=await crypto.subtle.digest('SHA-256',data);
                            const digest=Array.from(new Uint8Array(hash),x=>x.toString(16).padStart(2,'0')).join('');
                            if(immutable)cache.set(img.src,digest);
                            return digest;
                        }catch{return null;}
                    }));
                    if(hashes.some(value=>value===null))return {hashes,end:false};
                    let scroller=null;
                    for(let el=images[0];el&&el!==document.body;el=el.parentElement){
                        if(el.scrollHeight>el.clientHeight+10&&/auto|scroll/.test(getComputedStyle(el).overflowY)){
                            scroller=el;break;
                        }
                    }
                    if(!scroller)return {hashes,end:true};
                    const before=scroller.scrollTop;
                    scroller.scrollTop+=Math.max(100,scroller.clientHeight*0.7);
                    return {hashes,end:scroller.scrollTop===before};
                }""")
                found.update(value for value in result["hashes"] if value)
                if not any(value is None for value in result["hashes"]):
                    break
                if stopped():
                    return found
                if attempt == 4:
                    raise RuntimeError("飞书图片仍未加载完整，导入已暂停。网络恢复后点“继续核对并导入”，已保存的不会重复添加。")
                self._report("飞书图片正在加载，正在自动等待重试；可点“停止”。")
                page.wait_for_timeout(500)
            if until and set(until) <= found:
                return found
            if result["end"]:
                return found
            page.wait_for_timeout(180)
        if stopped():
            return found
        raise RuntimeError("飞书表情列表尚未核对完，已暂停导入；请稍后重试或使用 50 张分组手动导入。")

    def upload(self, files, stopped):
        self._added, self._already = [], []
        try:
            return self._upload(files, stopped)
        except (RuntimeError, BrowserError) as exc:
            confirmed = set(self._added + self._already)
            return {"added": self._added, "already": self._already,
                    "unconfirmed": [file for file in files if file not in confirmed],
                    "stopped": stopped(), "error": (
                        "飞书连接中断或浏览器已关闭。请检查网络后点“继续核对并导入”；已保存的不会重复添加。"
                        if isinstance(exc, BrowserError) else str(exc)),
                    "verification": "sha256_of_rendered_image_bytes"}

    def _upload(self, files, stopped):
        fingerprints = image_hashes(files)
        self.open_personal_panel()
        self._report("正在核对飞书里已有的表情，避免重复添加。")
        observed = self.scan_images(stopped)
        already = [file for file, digest in fingerprints.items() if digest in observed]
        self._already = already
        remaining = [file for file in files if file not in already]
        added = []
        self._added = added
        pending = []
        batches = partition(remaining)
        for number, group in enumerate(batches, 1):
            if stopped():
                pending.extend(group)
                continue
            self._report(f"正在导入第 {number}/{len(batches)} 批（{len(group)} 张）…", len(added)+len(already), len(files))
            self.open_personal_panel()
            with self._page.expect_file_chooser(timeout=10000) as chooser:
                self._page.locator('.add-sticker-btn').first.click()
            chooser.value.set_files(group)
            deadline = time.monotonic() + 60
            verified = []
            while time.monotonic() < deadline and not stopped():
                self._page.wait_for_timeout(1500)
                observed.update(self.scan_images(stopped, until={fingerprints[file] for file in group}))
                verified = [file for file in group if fingerprints[file] in observed]
                if len(verified) == len(group):
                    break
            added.extend(verified)
            unresolved = [file for file in group if file not in verified]
            if unresolved:
                pending.extend(unresolved)
                pending.extend(file for later in batches[number:] for file in later)
                break
        if added:
            # One final fresh scan for the entire run; intermediate scans stop at this batch.
            self._page.reload(wait_until='domcontentloaded')
            self._page.wait_for_timeout(1000)
            self.open_personal_panel()
            final = self.scan_images(lambda: False)
            added[:] = [file for file in added if fingerprints[file] in final]
            already[:] = [file for file in already if fingerprints[file] in final]
            pending = [file for file in files if file not in set(added + already)]
        return {"added": added, "already": already, "unconfirmed": pending,
                "stopped": stopped(), "verification": "sha256_of_rendered_image_bytes"}

"""macOS WeChat 4.x adapter. Delegate database/WAL reading to pinned wxemoticon."""

from __future__ import annotations

import hashlib
import os
import subprocess
from pathlib import Path
from urllib.parse import parse_qs, urlparse

import config


def helper_path() -> Path:
    return Path(config.APP_DIR) / "runtime" / "wxemoticon"


def wechat_app() -> Path:
    from macos_paths import application_path

    return application_path()


def query_emoji_entries(wx_dir: str, work_dir: str, callback=None) -> list[dict]:
    """Read favorite URLs, including committed WAL records; never log keys or URLs."""
    helper = helper_path()
    if not helper.is_file():
        raise RuntimeError("Mac 提取组件未安装，请运行 .venv/bin/python scripts/install_macos_helper.py")
    account = Path(wx_dir)
    urls_path = Path(work_dir) / "urls.txt"
    if callback:
        callback("[macOS] 正在读取微信收藏表情记录；首次使用需先退出微信，并在弹出的副本中登录。")
    result = subprocess.run(
        [str(helper), "--wechat-app", str(wechat_app()), "--wechat-data-dir", str(account.parent),
         "--no-interactive", "urls", "--wxid", account.name, "--out", str(urls_path),
         "--log", str(Path(work_dir) / "urls.log"), "--timeout", "180"],
        capture_output=True, text=True, timeout=240, check=False,
    )
    if result.returncode:
        # CLI diagnostics may contain paths; keep raw output out of application events.
        raise RuntimeError("Mac 表情记录读取失败：首次使用或密钥失效时，请先完全退出微信再导出；副本打开后需登录。")
    try:
        urls = urls_path.read_text(encoding="utf-8").splitlines()
    except (ValueError, OSError) as exc:
        raise RuntimeError("Mac 提取组件返回了无效结果。") from exc
    entries = []
    for url in urls:
        url = url.strip()
        if url.startswith(("https://", "http://")):
            digest = parse_qs(urlparse(url).query).get("m", [""])[0]
            if len(digest) != 32 or any(c not in "0123456789abcdefABCDEF" for c in digest):
                digest = hashlib.md5(url.encode()).hexdigest()
            entries.append({"md5": digest.lower(), "url": url, "source": "fav"})
    if not entries:
        raise RuntimeError("没有读取到可下载的收藏表情。请确认所选微信账号已同步收藏表情。")
    # wxemoticon writes its own per-account key cache with private permissions.
    os.chmod(urls_path, 0o600)
    if callback:
        callback(f"[macOS] 已读取 {len(entries)} 条收藏表情记录。")
    return entries

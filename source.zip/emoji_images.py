"""Image preparation that never intentionally replaces an animation with a still."""
from io import BytesIO

from PIL import Image


def validate_image(data):
    with Image.open(BytesIO(data)) as image:
        image.seek(getattr(image, "n_frames", 1) - 1)
        image.load()


def reusable_legacy_image(path, source, maximum):
    """Keep correctly animated/static legacy bytes to avoid duplicate remote stickers."""
    try:
        old = path.read_bytes()
        with Image.open(BytesIO(source)) as original, Image.open(BytesIO(old)) as previous:
            animated = getattr(original, "n_frames", 1) > 1
            if animated != (getattr(previous, "n_frames", 1) > 1) or max(previous.size) > maximum:
                return None
            def timing(image):
                duration = 0
                loop = image.info.get("loop")
                for index in range(getattr(image, "n_frames", 1)):
                    image.seek(index)
                    image.load()
                    duration += image.info.get("duration", 0)
                return duration, loop
            if animated and timing(original) != timing(previous):
                return None
            previous.seek(getattr(previous, "n_frames", 1) - 1)
            previous.load()
        return old
    except (OSError, ValueError, EOFError, IndexError):
        return None


def prepare_image(data, max_dimension, max_bytes):
    with Image.open(BytesIO(data)) as image:
        animated = getattr(image, "n_frames", 1) > 1
        if animated:
            if image.format == "GIF" and max(image.size) <= max_dimension and len(data) <= max_bytes:
                return data
            try:
                return _animation(image, max_dimension, max_bytes)
            except (OSError, ValueError, EOFError):
                # Preserve the animation if an encoder cannot handle it.
                return data
        if max(image.size) <= max_dimension and len(data) <= max_bytes:
            return data
        size = _size(image.size, max_dimension)
        frame = image.copy().resize(size, Image.Resampling.LANCZOS)
        fmt = image.format
        result = data
        for quality in range(90, 19, -10):
            output = BytesIO()
            options = {"quality": quality} if fmt in {"JPEG", "WEBP"} else {}
            frame.save(output, format=fmt, **options)
            result = output.getvalue()
            if len(result) <= max_bytes:
                break
        return result


def _size(size, maximum):
    ratio = min(1, maximum / max(size))
    return tuple(max(1, round(value * ratio)) for value in size)


def _animation(image, maximum, max_bytes):
    frames, durations = [], []
    loop = image.info.get("loop")
    first = 1 if image.format == "PNG" and image.info.get("default_image") else 0
    for index in range(first, image.n_frames):
        image.seek(index)
        # Pillow composites source disposal/blend; snapshot full RGBA canvases.
        frame = image.convert("RGBA")
        frames.append(frame)
        durations.append(round(image.info.get("duration", 100) / 10) * 10)
    edge = min(maximum, max(image.size))
    result = None
    for _attempt in range(8):
        size = _size(image.size, edge)
        scaled = [frame.resize(size, Image.Resampling.LANCZOS) for frame in frames]
        output = BytesIO()
        options = {"loop": loop} if loop is not None else {}
        scaled[0].save(output, format="GIF", save_all=True, append_images=scaled[1:],
                       duration=durations, disposal=2, optimize=False, **options)
        candidate = output.getvalue()
        with Image.open(BytesIO(candidate)) as check:
            if len(frames) > 1 and getattr(check, "n_frames", 1) < 2:
                raise ValueError("animation would become a still")
        result = candidate
        if len(result) <= max_bytes or edge <= 1:
            break
        edge = max(1, round(edge * 0.75))
    return result
